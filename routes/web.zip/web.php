<?php

use Illuminate\Support\Facades\Route;
use ProtoneMedia\LaravelFFMpeg;
use ProtoneMedia\LaravelFFMpeg\Filters\WatermarkFactory;
use Illuminate\Contracts\Filesystem\Filesystem;
use FFMpeg\Filters\Video\VideoFilters;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',function(){
	$media = FFMpeg::open('input.mp4')


	->export()
    ->inFormat(new \FFMpeg\Format\Video\X264)
    ->addFilter(function (VideoFilters $filters) {
        $filters->resize(new \FFMpeg\Coordinate\Dimension(3840, 2160));
    })
    ->save('4k.mkv')

	 ->export()
    ->inFormat(new \FFMpeg\Format\Video\X264)
    ->addFilter(function (VideoFilters $filters) {
        $filters->resize(new \FFMpeg\Coordinate\Dimension(1920, 1080));
    })
    ->save('1080p.mkv')


    ->export()
    ->inFormat(new \FFMpeg\Format\Video\X264)
    ->addFilter(function (VideoFilters $filters) {
        $filters->resize(new \FFMpeg\Coordinate\Dimension(1280, 720));
    })
    ->save('720p.mkv')

    ->export()
    ->inFormat(new \FFMpeg\Format\Video\X264)
    ->addFilter(function (VideoFilters $filters) {
        $filters->resize(new \FFMpeg\Coordinate\Dimension(852, 480));
    })
    ->save('480p.mkv');

    $durationInSeconds = $media->getDurationInSeconds(); // returns an int
    dd($durationInSeconds);
});

Route::get('/watermark', function () {

	$result = FFMpeg::open('input.mp4')
    ->addWatermark(function(WatermarkFactory $watermark) {
        $watermark->open('logo.png')
            ->left(25)
            ->bottom(25) 
            ->width(300)
            ->height(300);
    })->export()->inFormat(new \FFMpeg\Format\Video\X264)->save('water3.mkv');

    dd($result);
	// return view('welcome');
});

Route::post('add-overlay',function(Request $request){

	// first you have to get both input files in separate variables
	$video = $_FILES["video"]["name"];
	$image = $_FILES["image"]["name"];
	 

	try{
		// then you have to resize the selected image to lower resolution
		$command = "ffmpeg -i " . $image . " -s 128x128 output.jpeg";
	
		// execute that command
		system($command);
			echo "Overlay has been resized";
	 
	// both input files has been selected
	$command = "ffmpeg -i " . $video . " -i output.jpeg";
	 
	// now apply the filter to select both files
	// it must enclose in double quotes
	// [0:v] means first input which is video
	// [1:v] means second input which is resized image
	$command .= " -filter_complex \"[0:v][1:v]";
	 
	// now we need to tell the position of overlay in video
	$command .= " overlay=80:50\""; // closing double quotes
	 
	// save in a separate output file
	$command .= " -c:a copy output.mp4";
	 
	// execute the command
	system($command);
	 

	}catch(\Exception $e){
		dd('bad');
	}
	 
	 

	echo "Overlay has been added";
});
