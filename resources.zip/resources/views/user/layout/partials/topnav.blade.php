<nav class="navbar">
    <a class="sidebar-toggler">
        <i data-feather="menu"></i>
    </a>
    <div class="navbar-content">
        <ul class="navbar-nav">
            <li class="nav-item dropdown nav-profile">
                <a href="{{ url('user-logout') }}"><i data-feather="power"></i> Logout</a>
            </li>
        </ul>
    </div>
</nav>
