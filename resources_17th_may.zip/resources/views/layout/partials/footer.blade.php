<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between">
   <!--  <p class="text-muted text-center text-md-left mb-0 d-md-block">Copyright © 2020. All rights reserved</p> -->
</footer>
