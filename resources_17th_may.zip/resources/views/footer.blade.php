  <footer class="site-footer">
            <div class="container">   
               <div class="row">
                  <div class="col-lg-4 col-12">
                     <img style="width:40%; margin-top:-50px" src="{{asset('images/logo.png')}}">
                     <p>We are the African drone pilots, a team that aims to bring to you the most beautiful and impressive quality footages from Africa and all over the world. AFRICAN DRONE STOCK is aerial stock footage boutique consisting of the best drone video clips with High-Quality Content From All Over The World. </p>
                  </div>
                  
                  <div class="col-md-2 col-lg-2 col-sm-6">
                     <h2 class=" footer-heading mb-6">Others</h2>
                     <ul class="list-unstyled">
                        <li><a href="/about_us">About Us</a></li>
                        <li><a href="/contact_us">Contact Us</a></li>
                        <li><a href="/faqs">FAQS</a></li>
                        <li><a href="/privacy_policy">Privacy policy</a></li>
                        <li><a href="/refund_policy">Refund policy</a></li>
                        <li><a href="/terms_and_conditions">Terms & Conditions </a></li>
                     </ul>
                  </div>
                  <div class="col-md-2 col-lg-2 col-sm-6">
                     <h2 class=" footer-heading mb-6">Account</h2>
                     <ul class="list-unstyled">
                        <li><a href="#">Customer Dashboard</a></li>
                        <li><a href="#">Vendor Dashboard</a></li>
                     </ul>
                  </div>
                  <div style="opacity:0" class="col-lg-1">
                     <p>fhjashdjsah</p>
                  </div>
                  <div class="col-lg-3 col-12">
                  <h2 class=" footer-heading mb-6">Subscribe</h2>
                     <form action="/subscribe" method="post">
                        @csrf
                        <div class="input-group mb-3 pt-3">
                           <input type="email"required class="form-control border-secondary text-white bg-transparent" placeholder="Your Email Address" aria-label="Enter Email"  name="email" aria-describedby="button-addon2">
                           <div class="input-group-append">
                              <button class="btn btn-primary text-white" type="submit" id="button-addon2">SUBMIT</button>
                           </div>
                        </div>
                        <div class="row  pt-lg-5 pt-2">
                        <div class="col-md-3 col-sm-3">
                           <img class= "card" src="{{asset('images/visa.svg')}}" >
                        </div>
                        <div class="col-md-3 col-sm-3">
                           <img class= "card" src="{{asset('images/paypal-logo.svg')}}" >
                        </div>
                        <div class="col-md-3 col-sm-3">
                           <img class= "card" src="{{asset('images/mastercard.svg')}}" >
                        </div>
                        <div class="col-md-3 col-sm-3">
                           <img class= "card" src="{{asset('images/stripe.svg
                              ')}}" >
                        </div>
                        </div>
                     </form>
                  </div>
               </div>        
            </div>
         </footer>
         <div style="background-color: #30e3ca; padding: 5px;text-align: center; color: white; font-weight: 800">
         Copyright 2021 African Drone Stock, All rights reserved!
     	 </div>
       