<!DOCTYPE html>
<html lang="en-US" prefix="og: http://ogp.me/ns#">
<link rel="stylesheet" href="css/style.css">
<!-- Mirrored from africandronestock.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 16 May 2021 18:11:48 GMT -->
<!-- Added by HTTrack -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css"
        integrity="sha384-REHJTs1r2ErKBuJB0fCK99gCYsVjwxHrSU0N7I1zl9vZbggVJXRMsv/sLlOAGb4M" crossorigin="anonymous">

</head>

<!-- Begin Main Layout -->

<body data-rsssl=1
    class="home page-template page-template-full-width-template page-template-full-width-template-php page page-id-24 wp-custom-logo wp-embed-responsive essb-7.9 elementor-default elementor-kit-4792 elementor-page elementor-page-24">


    <div class="mayosis-wrapper">

        <header id="main-header" class="main-header header-stacked">
            <div class="header-top">
                <div class="container">


                    <div class="to-flex-row  th-flex-flex-middle">
                        <div class="to-flex-col th-col-left hidden-sm hidden-xs flexleft">


                            <ul class="top-social-icon">
                                <li><a href="#"
                                        target="_blank"><i class="zil zi-facebook"></i></a></li>


                                <li><a href="#" target="_blank"><i
                                            class="zil zi-instagram"></i></a></li>


                                <li><a href="#"
                                        target="_blank"><i class="zil zi-youtube"></i></a></li>



                            </ul>
                        </div>

                        <div class="to-flex-col th-col-center hidden-sm hidden-xs flexcenter">

                            <ul class="code-blocks">
                                <li class="html custom html_topbar_left">AFRICAN DRONE STOCK</li>
                            </ul>
                        </div><!-- center -->

                        <div class="to-flex-col th-col-right hidden-sm hidden-xs flexright">

                            <ul id="account-button" class="mayosis-option-menu hidden-xs hidden-sm">

                                <li class="menu-item">

                                    <a href="login/index.html" class="login-button"><i class="zil zi-user"></i>
                                        Login</a>
                                </li>

                            </ul>

                            <div id="account-mob" class="mayosis-option-menu hidden-md hidden-lg">

                                <div id="mayosis-sidemenu">

                                    <ul>
                                        <li class="menu-item">
                                            <a href="login/index.html"><i class="zil zi-user"></i> Login</a>
                                        </li>
                                    </ul>
                                </div>

                            </div>
                        </div><!-- .to-flex-col right -->


                        <div class="to-flex-col hidden-md hidden-lg flex-grow flexright">
                        </div>

                    </div><!-- .to-flex-row -->



                </div>
            </div><!-- .header-top -->

            <div class="header-master stickydisabled smartdisable">
                <div class="container-fluid">


                    <div class="to-flex-row  th-flex-flex-middle">

                        <!-- Start Desktop Content -->
                        <div class="to-flex-col th-col-left hidden-xs hidden-sm default-logo-box  flexleft">


                            <div class="site-logo sticky-enabled">

                                <a href="index.html" class="logo_box">

                                    <img src="images/logo.png"
                                        class="img-responsive main-logo hidden-xs hidden-sm" alt=""
                                        style="width:220px;" />

                                    <img src="images/logo.png"
                                        class="img-responsive main-logo hidden-md hidden-lg" alt=""
                                        style="width:130px;" />
                                    <img src="images/logo.png"
                                        class="img-responsive sticky-logo" alt="" style="width:220px;" />

                                </a>

                            </div>

                        </div>




                        <div class="to-flex-col th-col-center hidden-xs hidden-sm flexleft">

                            <div class="main-navigation text-right">
                                <div id="mayosis-menu" class="menu-menu-1-container">
                                    <ul id="menu-menu-1" class="menu">
                                        <li id="menu-item-8827"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-24 current_page_item active">
                                            <a href="index.html"> <span class="menu-item-text">Home</span></a></li>
                                        <li id="menu-item-8828"
                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children has-sub">
                                            <a> <span class="menu-item-text">CATEGORIES</span></a>
                                            <ul>
                                                <li id="menu-item-8824"
                                                    class="menu-item menu-item-type-post_type menu-item-object-page"><a
                                                        href="cityscape-aerials/index.html"> <span
                                                            class="menu-item-text">CITYSCAPE AERIALS</span></a></li>
                                                <li id="menu-item-8823"
                                                    class="menu-item menu-item-type-post_type menu-item-object-page"><a
                                                        href="sunset-cityscape/index.html"> <span
                                                            class="menu-item-text">SUNSET CITYSCAPE</span></a></li>
                                                <li id="menu-item-8830"
                                                    class="menu-item menu-item-type-post_type menu-item-object-page"><a
                                                        href="night-cityscape/index.html"> <span
                                                            class="menu-item-text">NIGHT CITYSCAPE</span></a></li>
                                                <li id="menu-item-8995"
                                                    class="menu-item menu-item-type-post_type menu-item-object-page"><a
                                                        href="nature-aerials/index.html"> <span
                                                            class="menu-item-text">NATURE AERIALS</span></a></li>
                                                <li id="menu-item-8826"
                                                    class="menu-item menu-item-type-post_type menu-item-object-page"><a
                                                        href="nature-sunset/index.html"> <span
                                                            class="menu-item-text">NATURE SUNSET</span></a></li>
                                                <li id="menu-item-8825"
                                                    class="menu-item menu-item-type-post_type menu-item-object-page"><a
                                                        href="time-lapses/index.html"> <span
                                                            class="menu-item-text">TIME-LAPSES</span></a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>


                        <div class="to-flex-col th-col-right hidden-sm hidden-xs flexright">





                            <ul id="cart-menu" class="mayosis-option-menu hidden-sm hidden-xs">

                                <li class="dropdown cart_widget cart-style-one"><a href="#" data-toggle="dropdown"
                                        class="cart-button"><i class="zil fa fa-shopping-cart"></i> <span
                                            class="items edd-cart-quantity">0</span></a>
                                    <ul role="menu" class="dropdown-menu mini_cart">
                                        <li class="widget">
                                            <div class="widget widget_edd_cart_widget">
                                                <p class="edd-cart-number-of-items" style="display:none;">Number of
                                                    items in cart: <span class="edd-cart-quantity">0</span></p>
                                                <ul class="edd-cart">

                                                    <li class="cart_item empty"><span class="edd_empty_cart">Your cart
                                                            is empty.</span></li>
                                                    <li class="cart_item edd-cart-meta edd_total" style="display:none;">
                                                        Total: <span class="cart-total">&#36;0.00</span></li>
                                                    <li class="cart_item edd_checkout" style="display:none;"><a
                                                            href="checkout-2/index.html">Checkout</a></li>

                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                </li>


                            </ul>

                            <ul class="mobile-cart hidden-md hidden-lg">
                                <li class="cart-style-one"><a href="checkout-2/index.html"
                                        class="btn btn-danger btn-lg mobile-cart-button">
                                        <i class="zil zi-cart"></i></a></li>

                            </ul>

                        </div>

                        <!-- End Desktop Content -->

                        <!-- Start Mobile Content -->

                        <div class="to-flex-col th-col-left hidden-md hidden-lg">



                            <div class="site-logo sticky-enabled">

                                <a href="index.html" class="logo_box">

                                    <img src="images/logo.png"
                                        class="img-responsive main-logo hidden-xs hidden-sm" alt=""
                                        style="width:220px;" />

                                    <img src="images/logo.png"
                                        class="img-responsive main-logo hidden-md hidden-lg" alt=""
                                        style="width:130px;" />
                                    <img src="images/logo.png"
                                        class="img-responsive sticky-logo" alt="" style="width:220px;" />

                                </a>

                            </div>


                        </div>

                        <div class="to-flex-col th-col-center hidden-md hidden-lg">


                        </div>


                        <div class="to-flex-col th-col-right hidden-md hidden-lg flexright">





                            <ul id="cart-menu" class="mayosis-option-menu hidden-sm hidden-xs">

                                <li class="dropdown cart_widget cart-style-one"><a href="#" data-toggle="dropdown"
                                        class="cart-button"><i class="zil fa fa-shopping-cart"></i> <span
                                            class="items edd-cart-quantity">0</span></a>
                                    <ul role="menu" class="dropdown-menu mini_cart">
                                        <li class="widget">
                                            <div class="widget widget_edd_cart_widget">
                                                <p class="edd-cart-number-of-items" style="display:none;">Number of
                                                    items in cart: <span class="edd-cart-quantity">0</span></p>
                                                <ul class="edd-cart">

                                                    <li class="cart_item empty"><span class="edd_empty_cart">Your cart
                                                            is empty.</span></li>
                                                    <li class="cart_item edd-cart-meta edd_total" style="display:none;">
                                                        Total: <span class="cart-total">&#36;0.00</span></li>
                                                    <li class="cart_item edd_checkout" style="display:none;"><a
                                                            href="checkout-2/index.html">Checkout</a></li>

                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                </li>


                            </ul>

                            <ul class="mobile-cart hidden-md hidden-lg">
                                <li class="cart-style-one"><a href="checkout-2/index.html"
                                        class="btn btn-danger btn-lg mobile-cart-button">
                                        <i class="zil zi-cart"></i></a></li>

                            </ul>
                            <div class="mobile--nav-menu">
                                <div class="top-part-mobile to-flex-row">
                                    <div class="to-flex-col th-col-left">
                                    </div>

                                    <div class="to-flex-col th-col-right">
                                    </div>
                                </div>

                                <div class="mobile-menu-main-part">
                                    <div class="col-sm-12 col-xs-12">
                                        <div id="mayosis-sidemenu" class="menu-menu-1-container">
                                            <ul id="menu-menu-2" class="menu">
                                                <li
                                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-24 current_page_item active">
                                                    <a href="index.html"> <span class="menu-item-class">Home</span></a>
                                                </li>
                                                <li
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children has-sub">
                                                    <a> <span class="menu-item-class">CATEGORIES</span></a>
                                                    <ul>
                                                        <li
                                                            class="menu-item menu-item-type-post_type menu-item-object-page">
                                                            <a href="cityscape-aerials/index.html"> <span
                                                                    class="menu-item-class">CITYSCAPE AERIALS</span></a>
                                                        </li>
                                                        <li
                                                            class="menu-item menu-item-type-post_type menu-item-object-page">
                                                            <a href="sunset-cityscape/index.html"> <span
                                                                    class="menu-item-class">SUNSET CITYSCAPE</span></a>
                                                        </li>
                                                        <li
                                                            class="menu-item menu-item-type-post_type menu-item-object-page">
                                                            <a href="night-cityscape/index.html"> <span
                                                                    class="menu-item-class">NIGHT CITYSCAPE</span></a>
                                                        </li>
                                                        <li
                                                            class="menu-item menu-item-type-post_type menu-item-object-page">
                                                            <a href="nature-aerials/index.html"> <span
                                                                    class="menu-item-class">NATURE AERIALS</span></a>
                                                        </li>
                                                        <li
                                                            class="menu-item menu-item-type-post_type menu-item-object-page">
                                                            <a href="nature-sunset/index.html"> <span
                                                                    class="menu-item-class">NATURE SUNSET</span></a>
                                                        </li>
                                                        <li
                                                            class="menu-item menu-item-type-post_type menu-item-object-page">
                                                            <a href="time-lapses/index.html"> <span
                                                                    class="menu-item-class">TIME-LAPSES</span></a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>


                                <div class="bottom-part-mobile to-flex-row">
                                    <div class="to-flex-col th-col-left">
                                    </div>

                                    <div class="to-flex-col th-col-right">
                                    </div>
                                </div>
                            </div>
                            <div class="overlaymobile"></div>
                            <ul class="mobile-nav">
                                <li class="burger"><span></span></li>
                            </ul>
                        </div>
                        <!-- End Mobile Content -->
                    </div>

                </div>
            </div><!-- .header-master -->

        </header>

        <div class="mayosis-container" style="background:#ffffff">

            <div data-elementor-type="wp-post" data-elementor-id="24" class="elementor elementor-24"
                data-elementor-settings="[]">
                <div class="elementor-inner">
                    <div class="elementor-section-wrap">

                        <section 
                            class="elementor-section elementor-top-section elementor-element elementor-element-16adda4 custom-bg-color elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="16adda4" data-element_type="section"
                            >
                            <div class="elementor-background-video-container">
                                 <div data-video="69yA-F7yOiQ" class="header__video js-background-video">
          <div class="header__background">
            <div id="yt-player"></div>
          </div>
        </div>
        <div class="header__video-overlay js-video-overlay" style="background-image: url('https://img.youtube.com/vi/69yA-F7yOiQ/maxresdefault.jpg');"></div>
     
                            </div>
                            <div class="elementor-background-overlay"></div>
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1c44438"
                                        data-id="1c44438" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-7da0020 elementor-widget elementor-widget-mayosis-theme-hero"
                                                    data-id="7da0020" data-element_type="widget"
                                                    data-widget_type="mayosis-theme-hero.default">
                                                    <div class="elementor-widget-container">

                                                        <!-- Element Code start -->

                                                        <div
                                                            class="col-md-12  col-xs-12 col-sm-12 mayosis_theme_hero_box">
                                                            <h1 class="hero-title">THE BEST AERIAL VIDEOS SHARED BY
                                                                TALLENTED CREATORS
                                                                <span class="mhero_counter_main">
                                                                </span>
                                                            </h1>
                                                            <div class="hero-description"></div>

                                                        </div>
                                                        <div class="clearfix"></div>

                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-32e332b elementor-widget elementor-widget-mayosis-search"
                                                    data-id="32e332b" data-element_type="widget"
                                                    data-widget_type="mayosis-search.default">
                                                    <div class="elementor-widget-container">

                                                        <!-- Element Code start -->
                                                        <div class="product-search-form style1">
                                                            <form method="GET" action="https://africandronestock.com/">

                                                                <div class='download_cat_filter '><select
                                                                        name='download_cats'>
                                                                        <option value='all'>All</option>
                                                                        <option value='nature-sunset'>NATURE SUNSET
                                                                        </option>
                                                                        <option value='night-cityscape'>CITYSCAPE NIGHT
                                                                        </option>
                                                                        <option value='timelapse'>TIMELAPSE</option>
                                                                        <option value='sunset-cityscape'>CITYSCAPE
                                                                            SUNSET</option>
                                                                        <option value='nature'>NATURE</option>
                                                                        <option value='cityscape'>CITYSCAPE</option>
                                                                    </select></div>

                                                                <div class="search-fields">
                                                                    <input name="s" value="" type="text"
                                                                        placeholder="Search Now">
                                                                    <input type="hidden" name="post_type"
                                                                        value="download">
                                                                    <span class="search-btn"><input value=""
                                                                            type="submit"></span>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section data-particle_enable="false" data-particle-mobile-disabled="false"
                            class="elementor-section elementor-top-section elementor-element elementor-element-85b239a elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="85b239a" data-element_type="section"
                            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-899d6e0"
                                        data-id="899d6e0" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-0dc32e0 elementor-widget elementor-widget-heading"
                                                    data-id="0dc32e0" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h1 class="elementor-heading-title elementor-size-default">OUR
                                                            CATEGORIES</h1>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section data-particle_enable="false" data-particle-mobile-disabled="false"
                            class="elementor-section elementor-top-section elementor-element elementor-element-dcd2318 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="dcd2318" data-element_type="section"
                            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-16 elementor-top-column elementor-element elementor-element-a2025a3"
                                        data-id="a2025a3" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-3e50a25 elementor-widget elementor-widget-image"
                                                    data-id="3e50a25" data-element_type="widget"
                                                    data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-image">
                                                            <a href="cityscape/index.html">
                                                                <img width="580" height="386"
                                                                    src="wp-content/uploads/2021/04/river-6175173_1280-1024x682.html"
                                                                    class="attachment-large size-large" alt=""
                                                                    loading="lazy"
                                                                    srcset="https://africandronestock.com/wp-content/uploads/2021/04/river-6175173_1280-1024x682.jpg 1024w, https://africandronestock.com/wp-content/uploads/2021/04/river-6175173_1280-300x200.jpg 300w, https://africandronestock.com/wp-content/uploads/2021/04/river-6175173_1280-768x512.jpg 768w, https://africandronestock.com/wp-content/uploads/2021/04/river-6175173_1280-150x100.jpg 150w, https://africandronestock.com/wp-content/uploads/2021/04/river-6175173_1280-720x480.jpg 720w, https://africandronestock.com/wp-content/uploads/2021/04/river-6175173_1280.jpg 1280w"
                                                                    sizes="(max-width: 580px) 100vw, 580px" /> </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-50b210f elementor-widget elementor-widget-heading"
                                                    data-id="50b210f" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h1 class="elementor-heading-title elementor-size-default"><a
                                                                href="cityscape/index.html">CITYSCAPE</a></h1>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="elementor-column elementor-col-16 elementor-top-column elementor-element elementor-element-bd50798"
                                        data-id="bd50798" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-0bcbb4a elementor-widget elementor-widget-image"
                                                    data-id="0bcbb4a" data-element_type="widget"
                                                    data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-image">
                                                            <a href="sunset-cityscape/index.html">
                                                                <img width="580" height="411"
                                                                    src="wp-content/uploads/2021/04/baku-eye-4626961_1920-1-1024x726.html"
                                                                    class="attachment-large size-large" alt=""
                                                                    loading="lazy"
                                                                    srcset="https://africandronestock.com/wp-content/uploads/2021/04/baku-eye-4626961_1920-1-1024x726.jpg 1024w, https://africandronestock.com/wp-content/uploads/2021/04/baku-eye-4626961_1920-1-300x213.jpg 300w, https://africandronestock.com/wp-content/uploads/2021/04/baku-eye-4626961_1920-1-768x545.jpg 768w, https://africandronestock.com/wp-content/uploads/2021/04/baku-eye-4626961_1920-1-1536x1090.jpg 1536w, https://africandronestock.com/wp-content/uploads/2021/04/baku-eye-4626961_1920-1.jpg 1920w"
                                                                    sizes="(max-width: 580px) 100vw, 580px" /> </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-3725ca6 elementor-widget elementor-widget-heading"
                                                    data-id="3725ca6" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h1 class="elementor-heading-title elementor-size-default"><a
                                                                href="night-cityscape/index.html">SUNSET CITYSCAPE</a>
                                                        </h1>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="elementor-column elementor-col-16 elementor-top-column elementor-element elementor-element-7a62c0c"
                                        data-id="7a62c0c" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-ad99d28 elementor-widget elementor-widget-image"
                                                    data-id="ad99d28" data-element_type="widget"
                                                    data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-image">
                                                            <a href="night-cityscape/index.html">
                                                                <img width="580" height="387"
                                                                    src="wp-content/uploads/2021/04/city-6156596-1-scaled-1024x683.html"
                                                                    class="attachment-large size-large" alt=""
                                                                    loading="lazy"
                                                                    srcset="https://africandronestock.com/wp-content/uploads/2021/04/city-6156596-1-scaled-1024x683.jpg 1024w, https://africandronestock.com/wp-content/uploads/2021/04/city-6156596-1-scaled-300x200.jpg 300w, https://africandronestock.com/wp-content/uploads/2021/04/city-6156596-1-scaled-768x512.jpg 768w, https://africandronestock.com/wp-content/uploads/2021/04/city-6156596-1-scaled-1536x1024.jpg 1536w, https://africandronestock.com/wp-content/uploads/2021/04/city-6156596-1-scaled-2048x1366.jpg 2048w, https://africandronestock.com/wp-content/uploads/2021/04/city-6156596-1-scaled-150x100.jpg 150w, https://africandronestock.com/wp-content/uploads/2021/04/city-6156596-1-scaled-720x480.jpg 720w"
                                                                    sizes="(max-width: 580px) 100vw, 580px" /> </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-1539f81 elementor-widget elementor-widget-heading"
                                                    data-id="1539f81" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h1 class="elementor-heading-title elementor-size-default"><a
                                                                href="index3a61.html?page_id=8765&amp;preview=true">NIGHT
                                                                CITYSCAPE</a></h1>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="elementor-column elementor-col-16 elementor-top-column elementor-element elementor-element-3d9b71f"
                                        data-id="3d9b71f" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-591c266 elementor-widget elementor-widget-image"
                                                    data-id="591c266" data-element_type="widget"
                                                    data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-image">
                                                            <a href="nature-aerials/index.html">
                                                                <img width="580" height="385"
                                                                    src="wp-content/uploads/2021/04/limestone-cliff-1792047_640.html"
                                                                    class="attachment-large size-large" alt=""
                                                                    loading="lazy"
                                                                    srcset="https://africandronestock.com/wp-content/uploads/2021/04/limestone-cliff-1792047_640.jpg 640w, https://africandronestock.com/wp-content/uploads/2021/04/limestone-cliff-1792047_640-300x199.jpg 300w, https://africandronestock.com/wp-content/uploads/2021/04/limestone-cliff-1792047_640-150x100.jpg 150w"
                                                                    sizes="(max-width: 580px) 100vw, 580px" /> </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-e1e91eb elementor-widget elementor-widget-heading"
                                                    data-id="e1e91eb" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h1 class="elementor-heading-title elementor-size-default"><a
                                                                href="nature-aerials/index.html">NATURE</a></h1>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="elementor-column elementor-col-16 elementor-top-column elementor-element elementor-element-4d30881"
                                        data-id="4d30881" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-de024e0 elementor-widget elementor-widget-image"
                                                    data-id="de024e0" data-element_type="widget"
                                                    data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-image">
                                                            <a href="nature/index.html">
                                                                <img width="580" height="331"
                                                                    src="wp-content/uploads/2021/04/tropical-1651423_640.html"
                                                                    class="attachment-large size-large" alt=""
                                                                    loading="lazy"
                                                                    srcset="https://africandronestock.com/wp-content/uploads/2021/04/tropical-1651423_640.jpg 640w, https://africandronestock.com/wp-content/uploads/2021/04/tropical-1651423_640-300x171.jpg 300w"
                                                                    sizes="(max-width: 580px) 100vw, 580px" /> </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-a0dbfcd elementor-widget elementor-widget-heading"
                                                    data-id="a0dbfcd" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h1 class="elementor-heading-title elementor-size-default"><a
                                                                href="nature/index.html">NATURE SUNSETS</a></h1>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="elementor-column elementor-col-16 elementor-top-column elementor-element elementor-element-1c1248d"
                                        data-id="1c1248d" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-9eb2b36 elementor-widget elementor-widget-image"
                                                    data-id="9eb2b36" data-element_type="widget"
                                                    data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-image">
                                                            <a href="timelapse/index.html">
                                                                <img width="580" height="386"
                                                                    src="wp-content/uploads/2021/04/sea-84629_1920-1-1024x681.html"
                                                                    class="attachment-large size-large" alt=""
                                                                    loading="lazy"
                                                                    srcset="https://africandronestock.com/wp-content/uploads/2021/04/sea-84629_1920-1-1024x681.jpg 1024w, https://africandronestock.com/wp-content/uploads/2021/04/sea-84629_1920-1-300x200.jpg 300w, https://africandronestock.com/wp-content/uploads/2021/04/sea-84629_1920-1-768x511.jpg 768w, https://africandronestock.com/wp-content/uploads/2021/04/sea-84629_1920-1-1536x1022.jpg 1536w, https://africandronestock.com/wp-content/uploads/2021/04/sea-84629_1920-1-150x100.jpg 150w, https://africandronestock.com/wp-content/uploads/2021/04/sea-84629_1920-1-720x480.jpg 720w, https://africandronestock.com/wp-content/uploads/2021/04/sea-84629_1920-1.jpg 1920w"
                                                                    sizes="(max-width: 580px) 100vw, 580px" /> </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-74db381 elementor-widget elementor-widget-heading"
                                                    data-id="74db381" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h1 class="elementor-heading-title elementor-size-default"><a
                                                                href="timelapse/index.html">TIME-LAPSES</a></h1>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section data-particle_enable="false" data-particle-mobile-disabled="false"
                            class="elementor-section elementor-top-section elementor-element elementor-element-e26d8b3 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="e26d8b3" data-element_type="section"
                            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-561d15f"
                                        data-id="561d15f" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-30aa770 elementor-widget elementor-widget-heading"
                                                    data-id="30aa770" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h1 class="elementor-heading-title elementor-size-default">Most
                                                            Recent Videos</h1>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section data-particle_enable="false" data-particle-mobile-disabled="false"
                            class="elementor-section elementor-top-section elementor-element elementor-element-79047b9 elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                            data-id="79047b9" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-c274fd0"
                                        data-id="c274fd0" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-029c0ce elementor-widget elementor-widget-mayosis-edd-recent"
                                                    data-id="029c0ce" data-element_type="widget"
                                                    data-widget_type="mayosis-edd-recent.default">
                                                    <div class="elementor-widget-container">


                                                        <div class="edd_fetured_ark">
                                                            <div class="ms--title--container">
                                                                <div class="title--box--full"
                                                                    style="margin-bottom:20px;">
                                                                    <div class="title--promo--box">
                                                                        <h3 class="section-title"> </h3>
                                                                    </div>

                                                                    <div class="title--button--box">

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row fix    ">

                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item night-cityscape  all ">
                                                                    <div
                                                                        class="post-11718 download type-download status-publish format-video hentry download_category-night-cityscape download_tag-cinematic-drone-shot download_tag-city download_tag-city-skyline download_tag-cityscape download_tag-drone-view download_tag-europe download_tag-high-angle-view download_tag-night download_tag-raw-footage edd-download edd-download-cat-night-cityscape edd-download-tag-cinematic-drone-shot edd-download-tag-city edd-download-tag-city-skyline edd-download-tag-cityscape edd-download-tag-drone-view edd-download-tag-europe edd-download-tag-high-angle-view edd-download-tag-night edd-download-tag-raw-footage">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <div
                                                                                    class="wrap-ribbon left-edge point lblue">
                                                                                    <span>New</span></div>
                                                                                <figure class="mayosis-fade-in"></figure>



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="../Final Video old .mp4"
                                                                                                class="mayosis-video-url"></a>

                                                                                                <video width="400" controls>
                                                                                                    <source src="../Final Video old .mp4" type="video/mp4">
                                                                                                    <source src="../Final Video old .mp4" type="video/ogg">
                                                                                                    Your browser does not support HTML video.
                                                                                                  </video>
                                                                                                  

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="../../../SELF Base/Final Video old .mp4"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/485c861a-2e57-4c55-992b-3b0ac504180c/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/wide-angle-pull-back-shot-of-london-city-at-night/index.html">
                                                                                                Wide Angle Pull Back
                                                                                                Shot Of London City At
                                                                                                Night </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_11718">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-8359 download type-download status-publish format-video hentry download_category-cityscape download_tag-buildings download_tag-cars download_tag-city download_tag-cityscape download_tag-elevated-view download_tag-fly-over-buildings download_tag-high-angle-lens download_tag-high-rise-buildings download_tag-landscape download_tag-offices download_tag-people download_tag-point-of-view download_tag-residencial-district download_tag-road download_tag-skyline download_tag-town download_tag-wide-angle edd-download edd-download-cat-cityscape edd-download-tag-buildings edd-download-tag-cars edd-download-tag-city edd-download-tag-cityscape edd-download-tag-elevated-view edd-download-tag-fly-over-buildings edd-download-tag-high-angle-lens edd-download-tag-high-rise-buildings edd-download-tag-landscape edd-download-tag-offices edd-download-tag-people edd-download-tag-point-of-view edd-download-tag-residencial-district edd-download-tag-road edd-download-tag-skyline edd-download-tag-town edd-download-tag-wide-angle">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/aerial-view-of-residential-and-industrial-areas-in-england-london/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/cad08818-08db-4b57-bd6c-7b8404048e53/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/aerial-view-of-residential-and-industrial-areas-in-england-london/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/cad08818-08db-4b57-bd6c-7b8404048e53/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/aerial-view-of-residential-and-industrial-areas-in-england-london/index.html">
                                                                                                Aerial View Of
                                                                                                Residential And
                                                                                                Industrial Areas In
                                                                                                England, London </a>
                                                                                        </h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_8359">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-8261 download type-download status-publish format-video hentry download_category-cityscape download_tag-city-covered-in-snow download_tag-park-covered-in-snow download_tag-snow download_tag-snowfall download_tag-snowflakes download_tag-snowing download_tag-snowing-in-a-park download_tag-snowing-in-the-city edd-download edd-download-cat-cityscape edd-download-tag-city-covered-in-snow edd-download-tag-park-covered-in-snow edd-download-tag-snow edd-download-tag-snowfall edd-download-tag-snowflakes edd-download-tag-snowing edd-download-tag-snowing-in-a-park edd-download-tag-snowing-in-the-city">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/city-park-covered-in-snow-low-altitude-aerial-view-london/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/f13e3b0d-6aa9-4f01-994c-be942edb3399/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/city-park-covered-in-snow-low-altitude-aerial-view-london/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/f13e3b0d-6aa9-4f01-994c-be942edb3399/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/city-park-covered-in-snow-low-altitude-aerial-view-london/index.html">
                                                                                                City Park Covered In
                                                                                                Snow Low Altitude Aerial
                                                                                                View, London </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_8261">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item nature  all ">
                                                                    <div
                                                                        class="post-10728 download type-download status-publish format-video hentry download_category-nature download_tag-african-cemetery download_tag-american-cemetery download_tag-cars download_tag-europe-cemetery download_tag-european-cemetery download_tag-grave-stone download_tag-grief download_tag-ground download_tag-headstone download_tag-memorial-cemetery download_tag-memorial-site download_tag-new-cemetery download_tag-old-cemetery download_tag-people-at-the-cemetery download_tag-quiet-cemetery download_tag-r-i-p download_tag-rest-in-peace download_tag-scary download_tag-stone download_tag-tombstones edd-download edd-download-cat-nature edd-download-tag-african-cemetery edd-download-tag-american-cemetery edd-download-tag-cars edd-download-tag-europe-cemetery edd-download-tag-european-cemetery edd-download-tag-grave-stone edd-download-tag-grief edd-download-tag-ground edd-download-tag-headstone edd-download-tag-memorial-cemetery edd-download-tag-memorial-site edd-download-tag-new-cemetery edd-download-tag-old-cemetery edd-download-tag-people-at-the-cemetery edd-download-tag-quiet-cemetery edd-download-tag-r-i-p edd-download-tag-rest-in-peace edd-download-tag-scary edd-download-tag-stone edd-download-tag-tombstones">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/close-shot-of-a-cemetery-cathedral-low-angle-aerial-shot/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/185db559-2bee-4e49-8600-3e72e7dda437/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/close-shot-of-a-cemetery-cathedral-low-angle-aerial-shot/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/185db559-2bee-4e49-8600-3e72e7dda437/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/close-shot-of-a-cemetery-cathedral-low-angle-aerial-shot/index.html">
                                                                                                Close Shot Of A Cemetery
                                                                                                Cathedral, Low Angle
                                                                                                Aerial Shot </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_10728">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item nature  all ">
                                                                    <div
                                                                        class="post-10695 download type-download status-publish format-video hentry download_category-nature download_tag-aerial-tombs download_tag-aerial-view download_tag-burial-site download_tag-buried download_tag-burying-ground download_tag-cemetery download_tag-christian-cemetery download_tag-christian-cross-on-cemetery download_tag-christian-symbols download_tag-church-yard download_tag-coffin download_tag-dead download_tag-death download_tag-funeral download_tag-grave download_tag-grave-stone download_tag-graves download_tag-grief download_tag-ground download_tag-headstone download_tag-memorial-cemetery download_tag-memorial-site download_tag-people-at-the-cemetery download_tag-scary edd-download edd-download-cat-nature edd-download-tag-aerial-tombs edd-download-tag-aerial-view edd-download-tag-burial-site edd-download-tag-buried edd-download-tag-burying-ground edd-download-tag-cemetery edd-download-tag-christian-cemetery edd-download-tag-christian-cross-on-cemetery edd-download-tag-christian-symbols edd-download-tag-church-yard edd-download-tag-coffin edd-download-tag-dead edd-download-tag-death edd-download-tag-funeral edd-download-tag-grave edd-download-tag-grave-stone edd-download-tag-graves edd-download-tag-grief edd-download-tag-ground edd-download-tag-headstone edd-download-tag-memorial-cemetery edd-download-tag-memorial-site edd-download-tag-people-at-the-cemetery edd-download-tag-scary">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/cinematic-tracking-shot-of-a-vehicle-leaving-a-cemetery-aerial/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/53bcf46d-a6d8-4b6e-b93d-f5ac78019237/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/cinematic-tracking-shot-of-a-vehicle-leaving-a-cemetery-aerial/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/53bcf46d-a6d8-4b6e-b93d-f5ac78019237/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/cinematic-tracking-shot-of-a-vehicle-leaving-a-cemetery-aerial/index.html">
                                                                                                Cinematic Tracking Shot
                                                                                                Of A Vehicle Leaving A
                                                                                                Cemetery Aerial </a>
                                                                                        </h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_10695">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item sunset-cityscape  all ">
                                                                    <div
                                                                        class="post-11238 download type-download status-publish format-video hentry download_category-sunset-cityscape download_tag-4k-raw download_tag-beautiful-background-people-walking download_tag-cinematic-shot download_tag-city download_tag-city-park download_tag-europe download_tag-family download_tag-friends download_tag-peak-hour-in-a-park download_tag-people download_tag-public-park download_tag-sunset download_tag-sunset-in-a-park edd-download edd-download-cat-sunset-cityscape edd-download-tag-4k-raw edd-download-tag-beautiful-background-people-walking edd-download-tag-cinematic-shot edd-download-tag-city edd-download-tag-city-park edd-download-tag-europe edd-download-tag-family edd-download-tag-friends edd-download-tag-peak-hour-in-a-park edd-download-tag-people edd-download-tag-public-park edd-download-tag-sunset edd-download-tag-sunset-in-a-park">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/backwards-reveal-of-queen-elisabeth-olympic-park/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/30ef8046-adad-49e5-ad37-f16a8c79954e/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/backwards-reveal-of-queen-elisabeth-olympic-park/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/30ef8046-adad-49e5-ad37-f16a8c79954e/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/backwards-reveal-of-queen-elisabeth-olympic-park/index.html">
                                                                                                Backwards Reveal Of
                                                                                                Queen Elisabeth Olympic
                                                                                                Park </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_11238">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item nature  all ">
                                                                    <div
                                                                        class="post-8868 download type-download status-publish format-video hentry download_category-nature download_tag-cemetery download_tag-christian-cemetery download_tag-christian-cross-on-cemetery download_tag-christian-symbols download_tag-church-yard download_tag-coffin download_tag-dead download_tag-death download_tag-funeral download_tag-grave download_tag-grave-stone download_tag-graves edd-download edd-download-cat-nature edd-download-tag-cemetery edd-download-tag-christian-cemetery edd-download-tag-christian-cross-on-cemetery edd-download-tag-christian-symbols edd-download-tag-church-yard edd-download-tag-coffin edd-download-tag-dead edd-download-tag-death edd-download-tag-funeral edd-download-tag-grave edd-download-tag-grave-stone edd-download-tag-graves">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/a-well-decorated-tomb-infront-of-a-catholic-church-at-the-cemetery-aerial-3/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/e033f608-1d60-4add-b50a-bf85f6e0de90/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/a-well-decorated-tomb-infront-of-a-catholic-church-at-the-cemetery-aerial-3/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/e033f608-1d60-4add-b50a-bf85f6e0de90/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/a-well-decorated-tomb-infront-of-a-catholic-church-at-the-cemetery-aerial-3/index.html">
                                                                                                A Well Decorated Tomb
                                                                                                Infront Of A Catholic
                                                                                                Church At The Cemetery,
                                                                                                Aerial-3 </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_8868">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-9502 download type-download status-publish format-video hentry download_category-cityscape download_tag-4k-raw download_tag-aerial download_tag-blue-sky download_tag-busy-city download_tag-cars download_tag-city download_tag-cityscape download_tag-day download_tag-drone download_tag-elevated-view download_tag-high-angle-lens download_tag-high-street download_tag-landscape download_tag-overhead-shot download_tag-people download_tag-point-of-view download_tag-raw-footage download_tag-real-time download_tag-residential-community download_tag-residential-district download_tag-road download_tag-skyline download_tag-street download_tag-suburb download_tag-town download_tag-wide-angle edd-download edd-download-cat-cityscape edd-download-tag-4k-raw edd-download-tag-aerial edd-download-tag-blue-sky edd-download-tag-busy-city edd-download-tag-cars edd-download-tag-city edd-download-tag-cityscape edd-download-tag-day edd-download-tag-drone edd-download-tag-elevated-view edd-download-tag-high-angle-lens edd-download-tag-high-street edd-download-tag-landscape edd-download-tag-overhead-shot edd-download-tag-people edd-download-tag-point-of-view edd-download-tag-raw-footage edd-download-tag-real-time edd-download-tag-residential-community edd-download-tag-residential-district edd-download-tag-road edd-download-tag-skyline edd-download-tag-street edd-download-tag-suburb edd-download-tag-town edd-download-tag-wide-angle">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/orbiting-around-empty-train-station/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/8437c5b7-9f9c-4688-bed3-35c3b587031a/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/orbiting-around-empty-train-station/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/8437c5b7-9f9c-4688-bed3-35c3b587031a/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/orbiting-around-empty-train-station/index.html">
                                                                                                Orbiting Around Empty
                                                                                                Train Station </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_9502">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-10800 download type-download status-publish format-video hentry download_category-cityscape download_tag-architectural download_tag-architecture download_tag-banks download_tag-building download_tag-buildings download_tag-canary-water download_tag-capital-city-panorama download_tag-cars download_tag-city download_tag-cityscape download_tag-day download_tag-dockland download_tag-downtown download_tag-dust download_tag-england download_tag-eu download_tag-evening download_tag-finance download_tag-glass-buildings-city-aerial download_tag-high-angle-view download_tag-high-buildings download_tag-high-rise download_tag-high-street download_tag-landscape download_tag-london-city download_tag-office-buildings download_tag-organisation download_tag-rich-city download_tag-road download_tag-skyline download_tag-skyscraper download_tag-sundown download_tag-sunset download_tag-technology download_tag-tourist download_tag-uk download_tag-urban edd-download edd-download-cat-cityscape edd-download-tag-architectural edd-download-tag-architecture edd-download-tag-banks edd-download-tag-building edd-download-tag-buildings edd-download-tag-canary-water edd-download-tag-capital-city-panorama edd-download-tag-cars edd-download-tag-city edd-download-tag-cityscape edd-download-tag-day edd-download-tag-dockland edd-download-tag-downtown edd-download-tag-dust edd-download-tag-england edd-download-tag-eu edd-download-tag-evening edd-download-tag-finance edd-download-tag-glass-buildings-city-aerial edd-download-tag-high-angle-view edd-download-tag-high-buildings edd-download-tag-high-rise edd-download-tag-high-street edd-download-tag-landscape edd-download-tag-london-city edd-download-tag-office-buildings edd-download-tag-organisation edd-download-tag-rich-city edd-download-tag-road edd-download-tag-skyline edd-download-tag-skyscraper edd-download-tag-sundown edd-download-tag-sunset edd-download-tag-technology edd-download-tag-tourist edd-download-tag-uk edd-download-tag-urban">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/london-downtown-business-city-centre-skyscraperstowers-with-glasses/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/1fe3458d-bd3e-4b39-8662-dd07a2509a00/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/london-downtown-business-city-centre-skyscraperstowers-with-glasses/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/1fe3458d-bd3e-4b39-8662-dd07a2509a00/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/london-downtown-business-city-centre-skyscraperstowers-with-glasses/index.html">
                                                                                                London Downtown Business
                                                                                                City Centre,
                                                                                                Skyscrapers,Towers With
                                                                                                Glasses </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_10800">&#36;70.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-11691 download type-download status-publish format-video hentry download_category-cityscape download_tag-aerial download_tag-aerial-shot download_tag-architecture download_tag-building download_tag-busy-city-centre download_tag-cars download_tag-cars-cars download_tag-city download_tag-clouds download_tag-day download_tag-drone download_tag-hight-street download_tag-house download_tag-houses download_tag-landscape download_tag-london-city download_tag-low-angle download_tag-natural-lighting download_tag-nature download_tag-overhead download_tag-point-of-view download_tag-real-estate download_tag-real-time download_tag-residential-district download_tag-road download_tag-sky download_tag-skyline download_tag-street download_tag-summer download_tag-sunny download_tag-towers download_tag-town download_tag-tracking-shot download_tag-wide-angle edd-download edd-download-cat-cityscape edd-download-tag-aerial edd-download-tag-aerial-shot edd-download-tag-architecture edd-download-tag-building edd-download-tag-busy-city-centre edd-download-tag-cars edd-download-tag-cars-cars edd-download-tag-city edd-download-tag-clouds edd-download-tag-day edd-download-tag-drone edd-download-tag-hight-street edd-download-tag-house edd-download-tag-houses edd-download-tag-landscape edd-download-tag-london-city edd-download-tag-low-angle edd-download-tag-natural-lighting edd-download-tag-nature edd-download-tag-overhead edd-download-tag-point-of-view edd-download-tag-real-estate edd-download-tag-real-time edd-download-tag-residential-district edd-download-tag-road edd-download-tag-sky edd-download-tag-skyline edd-download-tag-street edd-download-tag-summer edd-download-tag-sunny edd-download-tag-towers edd-download-tag-town edd-download-tag-tracking-shot edd-download-tag-wide-angle">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <div
                                                                                    class="wrap-ribbon left-edge point lblue">
                                                                                    <span>New</span></div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/flying-low-over-countryside-traffic-light-of-moving-vehicles-europe-uk/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/9ccb7be6-387f-4d8f-b500-770b3d553fdb/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/flying-low-over-countryside-traffic-light-of-moving-vehicles-europe-uk/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/9ccb7be6-387f-4d8f-b500-770b3d553fdb/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/flying-low-over-countryside-traffic-light-of-moving-vehicles-europe-uk/index.html">
                                                                                                Flying Low Over
                                                                                                Countryside Traffic
                                                                                                Light Of Moving
                                                                                                Vehicles, Europe Uk </a>
                                                                                        </h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_11691">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-8277 download type-download status-publish format-video hentry download_category-cityscape download_tag-city-covered-in-snow download_tag-park-covered-in-snow download_tag-snow download_tag-snowfall download_tag-snowflakes download_tag-snowing download_tag-snowing-in-a-park download_tag-snowing-in-the-city edd-download edd-download-cat-cityscape edd-download-tag-city-covered-in-snow edd-download-tag-park-covered-in-snow edd-download-tag-snow edd-download-tag-snowfall edd-download-tag-snowflakes edd-download-tag-snowing edd-download-tag-snowing-in-a-park edd-download-tag-snowing-in-the-city">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/flying-through-heavy-snowfall-in-the-city-4k-raw-uk-london/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/607b85a0-ff73-4997-a634-f6ef628f5aa0/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/flying-through-heavy-snowfall-in-the-city-4k-raw-uk-london/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/607b85a0-ff73-4997-a634-f6ef628f5aa0/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/flying-through-heavy-snowfall-in-the-city-4k-raw-uk-london/index.html">
                                                                                                Flying Through Heavy
                                                                                                Snowfall In The City 4K
                                                                                                Raw, Uk, London </a>
                                                                                        </h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_8277">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-9802 download type-download status-publish format-video hentry download_category-cityscape download_tag-aerial-view download_tag-architecture download_tag-business-buildings download_tag-canary-wharf download_tag-capital download_tag-cars download_tag-city-buildings-downtown download_tag-city-capital download_tag-city-life download_tag-city-view download_tag-complex-design download_tag-drone-city-view-london-street download_tag-europe download_tag-europe-capital download_tag-expensive-city-banks download_tag-financial-district download_tag-futuristic download_tag-glass-building download_tag-headquarters download_tag-high-street download_tag-international download_tag-london-city download_tag-london-landmarks download_tag-london-skyline download_tag-metropolitan download_tag-monument download_tag-sunny-day download_tag-tallest-skyscrapers download_tag-tower download_tag-twilight edd-download edd-download-cat-cityscape edd-download-tag-aerial-view edd-download-tag-architecture edd-download-tag-business-buildings edd-download-tag-canary-wharf edd-download-tag-capital edd-download-tag-cars edd-download-tag-city-buildings-downtown edd-download-tag-city-capital edd-download-tag-city-life edd-download-tag-city-view edd-download-tag-complex-design edd-download-tag-drone-city-view-london-street edd-download-tag-europe edd-download-tag-europe-capital edd-download-tag-expensive-city-banks edd-download-tag-financial-district edd-download-tag-futuristic edd-download-tag-glass-building edd-download-tag-headquarters edd-download-tag-high-street edd-download-tag-international edd-download-tag-london-city edd-download-tag-london-landmarks edd-download-tag-london-skyline edd-download-tag-metropolitan edd-download-tag-monument edd-download-tag-sunny-day edd-download-tag-tallest-skyscrapers edd-download-tag-tower edd-download-tag-twilight">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/abstract-city-building-skyline-metropolitan-area-in-contemporary-color-style-and-futuristic-effects/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/19907837-b983-4887-b6e3-efa3d6db4ba6/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/abstract-city-building-skyline-metropolitan-area-in-contemporary-color-style-and-futuristic-effects/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/19907837-b983-4887-b6e3-efa3d6db4ba6/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/abstract-city-building-skyline-metropolitan-area-in-contemporary-color-style-and-futuristic-effects/index.html">
                                                                                                Abstract City Building
                                                                                                Skyline Metropolitan
                                                                                                Area In Contemporary
                                                                                                Color Style And
                                                                                                Futuristic Effects </a>
                                                                                        </h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_9802">&#36;70.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-10472 download type-download status-publish format-video hentry download_category-cityscape download_tag-aerial-view download_tag-architecture download_tag-business-buildings download_tag-canary-wharf download_tag-capital download_tag-cars download_tag-city-buildings-downtown download_tag-city-capital download_tag-city-life download_tag-city-view download_tag-complex-design download_tag-drone-city-view-london-street download_tag-europe download_tag-europe-capital download_tag-expensive-city-banks download_tag-financial-district download_tag-futuristic download_tag-glass-building download_tag-headquarters download_tag-high-street download_tag-international download_tag-london-city download_tag-london-landmarks download_tag-london-skyline download_tag-metropolitan download_tag-monument download_tag-tallest-skyscrapers download_tag-tower download_tag-twilight edd-download edd-download-cat-cityscape edd-download-tag-aerial-view edd-download-tag-architecture edd-download-tag-business-buildings edd-download-tag-canary-wharf edd-download-tag-capital edd-download-tag-cars edd-download-tag-city-buildings-downtown edd-download-tag-city-capital edd-download-tag-city-life edd-download-tag-city-view edd-download-tag-complex-design edd-download-tag-drone-city-view-london-street edd-download-tag-europe edd-download-tag-europe-capital edd-download-tag-expensive-city-banks edd-download-tag-financial-district edd-download-tag-futuristic edd-download-tag-glass-building edd-download-tag-headquarters edd-download-tag-high-street edd-download-tag-international edd-download-tag-london-city edd-download-tag-london-landmarks edd-download-tag-london-skyline edd-download-tag-metropolitan edd-download-tag-monument edd-download-tag-tallest-skyscrapers edd-download-tag-tower edd-download-tag-twilight">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/central-european-city-buildings-drone-view/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/f5e3563b-3464-4450-a8d7-793f059a11d1/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/central-european-city-buildings-drone-view/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/f5e3563b-3464-4450-a8d7-793f059a11d1/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/central-european-city-buildings-drone-view/index.html">
                                                                                                Central European City
                                                                                                Buildings Drone View
                                                                                            </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_10472">&#36;70.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item nature  all ">
                                                                    <div
                                                                        class="post-8981 download type-download status-publish format-video hentry download_category-nature download_tag-beautiful-park download_tag-cinematic download_tag-environment download_tag-green-field download_tag-green-filed-in-spring download_tag-green-grass download_tag-green-lawn download_tag-green-park download_tag-nature download_tag-panoramic download_tag-quiet-green-filed download_tag-quiet-green-park download_tag-quiet-nature download_tag-scenic download_tag-serene-environment download_tag-spring download_tag-trees edd-download edd-download-cat-nature edd-download-tag-beautiful-park edd-download-tag-cinematic edd-download-tag-environment edd-download-tag-green-field edd-download-tag-green-filed-in-spring edd-download-tag-green-grass edd-download-tag-green-lawn edd-download-tag-green-park edd-download-tag-nature edd-download-tag-panoramic edd-download-tag-quiet-green-filed edd-download-tag-quiet-green-park edd-download-tag-quiet-nature edd-download-tag-scenic edd-download-tag-serene-environment edd-download-tag-spring edd-download-tag-trees">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/amazing-green-park-with-beautiful-trees-in-summer/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/fdaf9e08-d801-43ff-ada3-e428987aadae/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/amazing-green-park-with-beautiful-trees-in-summer/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/fdaf9e08-d801-43ff-ada3-e428987aadae/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/amazing-green-park-with-beautiful-trees-in-summer/index.html">
                                                                                                Amazing Green Park With
                                                                                                Beautiful Trees In
                                                                                                Summer </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_8981">&#36;35.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-11746 download type-download status-publish format-video hentry download_category-cityscape download_tag-aerial download_tag-beautiful-ducks download_tag-beautiful-sky download_tag-birds download_tag-birds-eating download_tag-birds-flying-over-water download_tag-blue-sky download_tag-city download_tag-city-doves download_tag-city-lake download_tag-city-swans-in-a-pool download_tag-cityscape download_tag-community download_tag-doves download_tag-duck-beach download_tag-duck-pool download_tag-ducks-eating download_tag-ducks-lake download_tag-ducks-playing download_tag-ducks-relaxing download_tag-ducks-swimming download_tag-feather download_tag-flying-duck download_tag-flying-low download_tag-flying-over-ducks download_tag-lake download_tag-lake-of-ducks download_tag-low-angle-flight download_tag-many-swans download_tag-nature download_tag-outdoors download_tag-people download_tag-pigeon download_tag-pond download_tag-seagull download_tag-seagulls-flying download_tag-summer download_tag-sunny download_tag-swans download_tag-swans-pool download_tag-swim download_tag-water-animal edd-download edd-download-cat-cityscape edd-download-tag-aerial edd-download-tag-beautiful-ducks edd-download-tag-beautiful-sky edd-download-tag-birds edd-download-tag-birds-eating edd-download-tag-birds-flying-over-water edd-download-tag-blue-sky edd-download-tag-city edd-download-tag-city-doves edd-download-tag-city-lake edd-download-tag-city-swans-in-a-pool edd-download-tag-cityscape edd-download-tag-community edd-download-tag-doves edd-download-tag-duck-beach edd-download-tag-duck-pool edd-download-tag-ducks-eating edd-download-tag-ducks-lake edd-download-tag-ducks-playing edd-download-tag-ducks-relaxing edd-download-tag-ducks-swimming edd-download-tag-feather edd-download-tag-flying-duck edd-download-tag-flying-low edd-download-tag-flying-over-ducks edd-download-tag-lake edd-download-tag-lake-of-ducks edd-download-tag-low-angle-flight edd-download-tag-many-swans edd-download-tag-nature edd-download-tag-outdoors edd-download-tag-people edd-download-tag-pigeon edd-download-tag-pond edd-download-tag-seagull edd-download-tag-seagulls-flying edd-download-tag-summer edd-download-tag-sunny edd-download-tag-swans edd-download-tag-swans-pool edd-download-tag-swim edd-download-tag-water-animal">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <div
                                                                                    class="wrap-ribbon left-edge point lblue">
                                                                                    <span>New</span></div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/flying-through-birds-in-a-pond-in-the-city-town/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/1b3af67d-de48-4514-81a9-e1a05d3174a6/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/flying-through-birds-in-a-pond-in-the-city-town/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/1b3af67d-de48-4514-81a9-e1a05d3174a6/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/flying-through-birds-in-a-pond-in-the-city-town/index.html">
                                                                                                Flying Through Birds In
                                                                                                A Pond In The City Town
                                                                                            </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_11746">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-10627 download type-download status-publish format-video hentry download_category-cityscape download_tag-aerial-view download_tag-architecture download_tag-business-buildings download_tag-canary-wharf download_tag-capital download_tag-cars download_tag-city-buildings-downtown download_tag-city-capital download_tag-city-life download_tag-city-view download_tag-complex-design download_tag-drone-city-view-london-street download_tag-europe download_tag-europe-capital download_tag-expensive-city-banks download_tag-financial-district download_tag-futuristic download_tag-glass-building download_tag-headquarters download_tag-high-street download_tag-international download_tag-london-city download_tag-london-landmarks download_tag-london-skyline download_tag-metropolitan download_tag-monument download_tag-tallest-skyscrapers download_tag-tower download_tag-twilight edd-download edd-download-cat-cityscape edd-download-tag-aerial-view edd-download-tag-architecture edd-download-tag-business-buildings edd-download-tag-canary-wharf edd-download-tag-capital edd-download-tag-cars edd-download-tag-city-buildings-downtown edd-download-tag-city-capital edd-download-tag-city-life edd-download-tag-city-view edd-download-tag-complex-design edd-download-tag-drone-city-view-london-street edd-download-tag-europe edd-download-tag-europe-capital edd-download-tag-expensive-city-banks edd-download-tag-financial-district edd-download-tag-futuristic edd-download-tag-glass-building edd-download-tag-headquarters edd-download-tag-high-street edd-download-tag-international edd-download-tag-london-city edd-download-tag-london-landmarks edd-download-tag-london-skyline edd-download-tag-metropolitan edd-download-tag-monument edd-download-tag-tallest-skyscrapers edd-download-tag-tower edd-download-tag-twilight">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/flying-over-water-revealing-cityscape-at-the-background-low-angle-aerial/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/1ca18c0f-53f4-41bd-a997-637a7e32d173/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/flying-over-water-revealing-cityscape-at-the-background-low-angle-aerial/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/1ca18c0f-53f4-41bd-a997-637a7e32d173/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/flying-over-water-revealing-cityscape-at-the-background-low-angle-aerial/index.html">
                                                                                                Flying Over Water
                                                                                                Revealing Cityscape At
                                                                                                The Background, Low
                                                                                                Angle Aerial </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_10627">&#36;70.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item sunset-cityscape  all ">
                                                                    <div
                                                                        class="post-11616 download type-download status-publish format-video hentry download_category-sunset-cityscape download_tag-beautiful-background-people-walking download_tag-city-park download_tag-family download_tag-friends download_tag-low-angle download_tag-peak-hour-in-a-park download_tag-people download_tag-public-park download_tag-sunset download_tag-sunset-in-a-park edd-download edd-download-cat-sunset-cityscape edd-download-tag-beautiful-background-people-walking edd-download-tag-city-park edd-download-tag-family edd-download-tag-friends edd-download-tag-low-angle edd-download-tag-peak-hour-in-a-park edd-download-tag-people edd-download-tag-public-park edd-download-tag-sunset edd-download-tag-sunset-in-a-park">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <div
                                                                                    class="wrap-ribbon left-edge point lblue">
                                                                                    <span>New</span></div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/flying-low-over-people-walking-in-a-park/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/e58cb969-530a-460e-a425-9eddcae1a03e/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/flying-low-over-people-walking-in-a-park/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/e58cb969-530a-460e-a425-9eddcae1a03e/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/flying-low-over-people-walking-in-a-park/index.html">
                                                                                                Flying Low Over People
                                                                                                Walking In A Park </a>
                                                                                        </h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_11616">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-10565 download type-download status-publish format-video hentry download_category-cityscape download_tag-aerial download_tag-architecture download_tag-building download_tag-business download_tag-cars download_tag-central download_tag-city download_tag-city-buildings download_tag-cityscape download_tag-commercial download_tag-corporate download_tag-economy download_tag-estate download_tag-expensive-city-transport download_tag-famous download_tag-financial download_tag-financial-city-urban download_tag-fortune download_tag-high-rise-buildings download_tag-high-street download_tag-market download_tag-metropolitan download_tag-office-buildings download_tag-offices download_tag-river download_tag-road download_tag-skyline download_tag-skyscrapers download_tag-stock-exchange download_tag-street download_tag-success download_tag-tall-buildings download_tag-tallest download_tag-travel download_tag-world-buildings-skyscraper edd-download edd-download-cat-cityscape edd-download-tag-aerial edd-download-tag-architecture edd-download-tag-building edd-download-tag-business edd-download-tag-cars edd-download-tag-central edd-download-tag-city edd-download-tag-city-buildings edd-download-tag-cityscape edd-download-tag-commercial edd-download-tag-corporate edd-download-tag-economy edd-download-tag-estate edd-download-tag-expensive-city-transport edd-download-tag-famous edd-download-tag-financial edd-download-tag-financial-city-urban edd-download-tag-fortune edd-download-tag-high-rise-buildings edd-download-tag-high-street edd-download-tag-market edd-download-tag-metropolitan edd-download-tag-office-buildings edd-download-tag-offices edd-download-tag-river edd-download-tag-road edd-download-tag-skyline edd-download-tag-skyscrapers edd-download-tag-stock-exchange edd-download-tag-street edd-download-tag-success edd-download-tag-tall-buildings edd-download-tag-tallest edd-download-tag-travel edd-download-tag-world-buildings-skyscraper">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/eu-modern-european-complex-of-residential-apartment-buildings/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/762911d2-6d91-4397-9749-370fe908d715/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/eu-modern-european-complex-of-residential-apartment-buildings/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/762911d2-6d91-4397-9749-370fe908d715/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/eu-modern-european-complex-of-residential-apartment-buildings/index.html">
                                                                                                Eu Modern European
                                                                                                Complex Of Residential
                                                                                                Apartment Buildings </a>
                                                                                        </h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_10565">&#36;70.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item sunset-cityscape  all ">
                                                                    <div
                                                                        class="post-11673 download type-download status-publish format-video hentry download_category-sunset-cityscape download_tag-busy-road download_tag-city-road download_tag-drone-view download_tag-dual-carriage-motorway download_tag-fast-moving-vehicles download_tag-flying-over-cars-m16-highway download_tag-highway-drone-shot download_tag-road download_tag-sunset download_tag-sunset-on-highway download_tag-vehicle-track edd-download edd-download-cat-sunset-cityscape edd-download-tag-busy-road edd-download-tag-city-road edd-download-tag-drone-view edd-download-tag-dual-carriage-motorway edd-download-tag-fast-moving-vehicles edd-download-tag-flying-over-cars-m16-highway edd-download-tag-highway-drone-shot edd-download-tag-road edd-download-tag-sunset edd-download-tag-sunset-on-highway edd-download-tag-vehicle-track">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <div
                                                                                    class="wrap-ribbon left-edge point lblue">
                                                                                    <span>New</span></div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/panaroma-view-of-a-busy-city-highway-during-sunset/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/5441b387-9c02-4740-9980-875068aa1ff5/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/panaroma-view-of-a-busy-city-highway-during-sunset/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/5441b387-9c02-4740-9980-875068aa1ff5/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/panaroma-view-of-a-busy-city-highway-during-sunset/index.html">
                                                                                                Panaroma View Of A Busy
                                                                                                City Highway During
                                                                                                Sunset </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_11673">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item nature  all ">
                                                                    <div
                                                                        class="post-10726 download type-download status-publish format-video hentry download_category-nature download_tag-african-cemetery download_tag-american-cemetery download_tag-cars download_tag-europe-cemetery download_tag-european-cemetery download_tag-grave-stone download_tag-grief download_tag-ground download_tag-headstone download_tag-memorial-cemetery download_tag-memorial-site download_tag-new-cemetery download_tag-old-cemetery download_tag-people-at-the-cemetery download_tag-quiet-cemetery download_tag-r-i-p download_tag-rest-in-peace download_tag-scary download_tag-stone download_tag-tombstones edd-download edd-download-cat-nature edd-download-tag-african-cemetery edd-download-tag-american-cemetery edd-download-tag-cars edd-download-tag-europe-cemetery edd-download-tag-european-cemetery edd-download-tag-grave-stone edd-download-tag-grief edd-download-tag-ground edd-download-tag-headstone edd-download-tag-memorial-cemetery edd-download-tag-memorial-site edd-download-tag-new-cemetery edd-download-tag-old-cemetery edd-download-tag-people-at-the-cemetery edd-download-tag-quiet-cemetery edd-download-tag-r-i-p edd-download-tag-rest-in-peace edd-download-tag-scary edd-download-tag-stone edd-download-tag-tombstones">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/closing-shot-of-cemetery-catherdral-aerial/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/00455d7d-39aa-479b-acbe-31751273075c/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/closing-shot-of-cemetery-catherdral-aerial/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/00455d7d-39aa-479b-acbe-31751273075c/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/closing-shot-of-cemetery-catherdral-aerial/index.html">
                                                                                                Closing Shot Of Cemetery
                                                                                                Catherdral, Aerial </a>
                                                                                        </h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_10726">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-11607 download type-download status-publish format-video hentry download_category-cityscape download_tag-aerial download_tag-architecture download_tag-building download_tag-business download_tag-cars download_tag-central download_tag-city download_tag-city-buildings download_tag-cityscape download_tag-commercial download_tag-corporate download_tag-economy download_tag-estate download_tag-expensive-city-transport download_tag-famous download_tag-financial download_tag-financial-city-urban download_tag-fortune download_tag-high-rise-buildings download_tag-high-street download_tag-market download_tag-metropolitan download_tag-office-buildings download_tag-offices download_tag-river download_tag-road download_tag-skyline download_tag-skyscrapers download_tag-stock-exchange download_tag-street download_tag-success download_tag-tall-buildings download_tag-tallest download_tag-travel download_tag-world-buildings-skyscraper edd-download edd-download-cat-cityscape edd-download-tag-aerial edd-download-tag-architecture edd-download-tag-building edd-download-tag-business edd-download-tag-cars edd-download-tag-central edd-download-tag-city edd-download-tag-city-buildings edd-download-tag-cityscape edd-download-tag-commercial edd-download-tag-corporate edd-download-tag-economy edd-download-tag-estate edd-download-tag-expensive-city-transport edd-download-tag-famous edd-download-tag-financial edd-download-tag-financial-city-urban edd-download-tag-fortune edd-download-tag-high-rise-buildings edd-download-tag-high-street edd-download-tag-market edd-download-tag-metropolitan edd-download-tag-office-buildings edd-download-tag-offices edd-download-tag-river edd-download-tag-road edd-download-tag-skyline edd-download-tag-skyscrapers edd-download-tag-stock-exchange edd-download-tag-street edd-download-tag-success edd-download-tag-tall-buildings edd-download-tag-tallest edd-download-tag-travel edd-download-tag-world-buildings-skyscraper">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <div
                                                                                    class="wrap-ribbon left-edge point lblue">
                                                                                    <span>New</span></div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/visualization-of-modern-glass-commercial-building/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/69fd2cf8-c1af-4cdd-81b5-aea9e64371ca/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/visualization-of-modern-glass-commercial-building/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/69fd2cf8-c1af-4cdd-81b5-aea9e64371ca/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/visualization-of-modern-glass-commercial-building/index.html">
                                                                                                Visualization Of Modern
                                                                                                Glass Commercial
                                                                                                Building </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_11607">&#36;70.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-10773 download type-download status-publish format-video hentry download_category-cityscape download_tag-aerial-view download_tag-architecture download_tag-business-buildings download_tag-canary-wharf download_tag-capital download_tag-cars download_tag-city-buildings-downtown download_tag-city-capital download_tag-city-life download_tag-city-view download_tag-complex-design download_tag-drone-city-view-london-street download_tag-europe download_tag-europe-capital download_tag-expensive-city-banks download_tag-financial-district download_tag-futuristic download_tag-glass-building download_tag-headquarters download_tag-high-street download_tag-international download_tag-london-city download_tag-london-landmarks download_tag-london-skyline download_tag-metropolitan download_tag-monument download_tag-tallest-skyscrapers download_tag-tower download_tag-twilight edd-download edd-download-cat-cityscape edd-download-tag-aerial-view edd-download-tag-architecture edd-download-tag-business-buildings edd-download-tag-canary-wharf edd-download-tag-capital edd-download-tag-cars edd-download-tag-city-buildings-downtown edd-download-tag-city-capital edd-download-tag-city-life edd-download-tag-city-view edd-download-tag-complex-design edd-download-tag-drone-city-view-london-street edd-download-tag-europe edd-download-tag-europe-capital edd-download-tag-expensive-city-banks edd-download-tag-financial-district edd-download-tag-futuristic edd-download-tag-glass-building edd-download-tag-headquarters edd-download-tag-high-street edd-download-tag-international edd-download-tag-london-city edd-download-tag-london-landmarks edd-download-tag-london-skyline edd-download-tag-metropolitan edd-download-tag-monument edd-download-tag-tallest-skyscrapers edd-download-tag-tower edd-download-tag-twilight">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/lockdown-aerial-view-of-canary-wharf-london-financial-business-and-banking-institutions/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/d75a85e7-9e9d-41c8-a727-1c633a976f71/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/lockdown-aerial-view-of-canary-wharf-london-financial-business-and-banking-institutions/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/d75a85e7-9e9d-41c8-a727-1c633a976f71/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/lockdown-aerial-view-of-canary-wharf-london-financial-business-and-banking-institutions/index.html">
                                                                                                Lockdown Aerial View Of
                                                                                                Canary Wharf London
                                                                                                Financial, Business And
                                                                                                Banking Institutions
                                                                                            </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_10773">&#36;70.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-10617 download type-download status-publish format-video hentry download_category-cityscape download_tag-architectural download_tag-architecture download_tag-banks download_tag-building download_tag-buildings download_tag-canary-water download_tag-capital-city-panorama download_tag-cars download_tag-city download_tag-cityscape download_tag-day download_tag-dockland download_tag-downtown download_tag-dust download_tag-england download_tag-eu download_tag-evening download_tag-finance download_tag-glass-buildings-city-aerial download_tag-high-angle-view download_tag-high-buildings download_tag-high-rise download_tag-high-street download_tag-landscape download_tag-london-city download_tag-office-buildings download_tag-organisation download_tag-rich-city download_tag-road download_tag-skyline download_tag-skyscraper download_tag-sundown download_tag-sunset download_tag-technology download_tag-tourist download_tag-uk download_tag-urban edd-download edd-download-cat-cityscape edd-download-tag-architectural edd-download-tag-architecture edd-download-tag-banks edd-download-tag-building edd-download-tag-buildings edd-download-tag-canary-water edd-download-tag-capital-city-panorama edd-download-tag-cars edd-download-tag-city edd-download-tag-cityscape edd-download-tag-day edd-download-tag-dockland edd-download-tag-downtown edd-download-tag-dust edd-download-tag-england edd-download-tag-eu edd-download-tag-evening edd-download-tag-finance edd-download-tag-glass-buildings-city-aerial edd-download-tag-high-angle-view edd-download-tag-high-buildings edd-download-tag-high-rise edd-download-tag-high-street edd-download-tag-landscape edd-download-tag-london-city edd-download-tag-office-buildings edd-download-tag-organisation edd-download-tag-rich-city edd-download-tag-road edd-download-tag-skyline edd-download-tag-skyscraper edd-download-tag-sundown edd-download-tag-sunset edd-download-tag-technology edd-download-tag-tourist edd-download-tag-uk edd-download-tag-urban">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/flying-into-the-financial-district-with-a-river-in-london/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/89f0c47a-045d-472b-b59b-d82ef2c94543/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/flying-into-the-financial-district-with-a-river-in-london/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/89f0c47a-045d-472b-b59b-d82ef2c94543/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/flying-into-the-financial-district-with-a-river-in-london/index.html">
                                                                                                Flying Into The
                                                                                                Financial District With
                                                                                                A River In London </a>
                                                                                        </h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_10617">&#36;70.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item nature  all ">
                                                                    <div
                                                                        class="post-10560 download type-download status-publish format-video hentry download_category-nature download_tag-burying-ground download_tag-cemetery download_tag-christian-cemetery download_tag-christian-cross-on-cemetery download_tag-christian-symbols download_tag-church-yard download_tag-coffin download_tag-dead download_tag-death download_tag-funeral download_tag-grave download_tag-grave-stone download_tag-graves download_tag-grief download_tag-ground download_tag-headstone edd-download edd-download-cat-nature edd-download-tag-burying-ground edd-download-tag-cemetery edd-download-tag-christian-cemetery edd-download-tag-christian-cross-on-cemetery edd-download-tag-christian-symbols edd-download-tag-church-yard edd-download-tag-coffin edd-download-tag-dead edd-download-tag-death edd-download-tag-funeral edd-download-tag-grave edd-download-tag-grave-stone edd-download-tag-graves edd-download-tag-grief edd-download-tag-ground edd-download-tag-headstone">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/cinematic-drone-view-of-a-beautiful-cemtery-with-people-and-cars-at-burial/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/81ab084c-d375-4399-8387-072b1c9cd0e8/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/cinematic-drone-view-of-a-beautiful-cemtery-with-people-and-cars-at-burial/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/81ab084c-d375-4399-8387-072b1c9cd0e8/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/cinematic-drone-view-of-a-beautiful-cemtery-with-people-and-cars-at-burial/index.html">
                                                                                                Cinematic Drone View Of
                                                                                                A Beautiful Cemtery With
                                                                                                People And Cars At
                                                                                                Burial </a></h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_10560">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-7867 download type-download status-publish format-video hentry download_category-cityscape download_tag-4k download_tag-4k-raw download_tag-aerial download_tag-aerial-shot download_tag-architecture download_tag-building download_tag-busy-city-centre download_tag-cars download_tag-cars-cars download_tag-city download_tag-cityscape download_tag-clouds download_tag-day download_tag-drone download_tag-elevated-view download_tag-forest-gate download_tag-h-265-town download_tag-hackney download_tag-high-angle-lens download_tag-hight-street download_tag-hlg download_tag-house download_tag-houses download_tag-landscape download_tag-leyton download_tag-london download_tag-london-city download_tag-low-angle download_tag-natural-lighting download_tag-nature download_tag-overhead download_tag-people download_tag-point-of-view download_tag-raw-footage download_tag-real-estate download_tag-real-time download_tag-residencial-district download_tag-road download_tag-sky download_tag-skyline download_tag-stratford download_tag-street download_tag-summer download_tag-sunny download_tag-towers download_tag-town download_tag-tracking-shot download_tag-uk download_tag-wanstead download_tag-wide-angle edd-download edd-download-cat-cityscape edd-download-tag-4k edd-download-tag-4k-raw edd-download-tag-aerial edd-download-tag-aerial-shot edd-download-tag-architecture edd-download-tag-building edd-download-tag-busy-city-centre edd-download-tag-cars edd-download-tag-cars-cars edd-download-tag-city edd-download-tag-cityscape edd-download-tag-clouds edd-download-tag-day edd-download-tag-drone edd-download-tag-elevated-view edd-download-tag-forest-gate edd-download-tag-h-265-town edd-download-tag-hackney edd-download-tag-high-angle-lens edd-download-tag-hight-street edd-download-tag-hlg edd-download-tag-house edd-download-tag-houses edd-download-tag-landscape edd-download-tag-leyton edd-download-tag-london edd-download-tag-london-city edd-download-tag-low-angle edd-download-tag-natural-lighting edd-download-tag-nature edd-download-tag-overhead edd-download-tag-people edd-download-tag-point-of-view edd-download-tag-raw-footage edd-download-tag-real-estate edd-download-tag-real-time edd-download-tag-residencial-district edd-download-tag-road edd-download-tag-sky edd-download-tag-skyline edd-download-tag-stratford edd-download-tag-street edd-download-tag-summer edd-download-tag-sunny edd-download-tag-towers edd-download-tag-town edd-download-tag-tracking-shot edd-download-tag-uk edd-download-tag-wanstead edd-download-tag-wide-angle">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/aerial-view-of-people-and-cyclists-crossing-a-busy-traffic-stop/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/486609ea-1e9d-4df3-a9e1-a4d20b540cf3/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/aerial-view-of-people-and-cyclists-crossing-a-busy-traffic-stop/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/486609ea-1e9d-4df3-a9e1-a4d20b540cf3/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/aerial-view-of-people-and-cyclists-crossing-a-busy-traffic-stop/index.html">
                                                                                                Aerial View Of People
                                                                                                And Cyclists Crossing A
                                                                                                Busy Traffic Stop </a>
                                                                                        </h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_7867">&#36;110.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item nature  all ">
                                                                    <div
                                                                        class="post-11767 download type-download status-publish format-video hentry download_category-nature download_tag-aerial-view download_tag-burial-site download_tag-buried download_tag-burying-ground download_tag-cemetery download_tag-christian-cemetery download_tag-christian-cross-on-cemetery download_tag-christian-symbols download_tag-church-yard download_tag-coffin download_tag-dead download_tag-death download_tag-funeral download_tag-grave download_tag-grave-stone download_tag-graves download_tag-grief download_tag-ground download_tag-headstone download_tag-memorial-site edd-download edd-download-cat-nature edd-download-tag-aerial-view edd-download-tag-burial-site edd-download-tag-buried edd-download-tag-burying-ground edd-download-tag-cemetery edd-download-tag-christian-cemetery edd-download-tag-christian-cross-on-cemetery edd-download-tag-christian-symbols edd-download-tag-church-yard edd-download-tag-coffin edd-download-tag-dead edd-download-tag-death edd-download-tag-funeral edd-download-tag-grave edd-download-tag-grave-stone edd-download-tag-graves edd-download-tag-grief edd-download-tag-ground edd-download-tag-headstone edd-download-tag-memorial-site">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <div
                                                                                    class="wrap-ribbon left-edge point lblue">
                                                                                    <span>New</span></div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/lonely-man-walks-to-his-car-in-a-quiet-cemetery-drone-tacking-shot-2/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/ccec46f0-6aa6-42b1-8b87-94f1d72b2241/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/lonely-man-walks-to-his-car-in-a-quiet-cemetery-drone-tacking-shot-2/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/ccec46f0-6aa6-42b1-8b87-94f1d72b2241/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/lonely-man-walks-to-his-car-in-a-quiet-cemetery-drone-tacking-shot-2/index.html">
                                                                                                Lonely Man Walks To His
                                                                                                Car In A Quiet Cemetery,
                                                                                                Drone Tacking Shot </a>
                                                                                        </h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_11767">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div
                                                                    class="col-md-4 col-xs-12 col-sm-4 element-item cityscape  all ">
                                                                    <div
                                                                        class="post-8228 download type-download status-publish format-video hentry download_category-cityscape download_tag-4k-raw download_tag-busy-road download_tag-capital-city download_tag-car-park download_tag-cars download_tag-city-life download_tag-city-view download_tag-cityscape download_tag-day download_tag-foo-people download_tag-raw download_tag-raw-footage download_tag-skyline download_tag-skyscrapers download_tag-sunny download_tag-tall-buildings download_tag-traffic edd-download edd-download-cat-cityscape edd-download-tag-4k-raw edd-download-tag-busy-road edd-download-tag-capital-city edd-download-tag-car-park edd-download-tag-cars edd-download-tag-city-life edd-download-tag-city-view edd-download-tag-cityscape edd-download-tag-day edd-download-tag-foo-people edd-download-tag-raw edd-download-tag-raw-footage edd-download-tag-skyline edd-download-tag-skyscrapers edd-download-tag-sunny edd-download-tag-tall-buildings edd-download-tag-traffic">
                                                                        <div class="grid_dm ribbon-box group edge">
                                                                            <div class="product-box"
                                                                                style="position: relative;">
                                                                                <div
                                                                                    style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                    <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                        style="height: 30px;"
                                                                                        alt="Logo" />
                                                                                </div>
                                                                                <figure class="mayosis-fade-in">



                                                                                    <div class="mayosis--video--box">
                                                                                        <div
                                                                                            class="video-inner-box-promo">
                                                                                            <a href="video/raw-footage-of-london-cityscape-from-mile-end-stratford-aerial/index.html"
                                                                                                class="mayosis-video-url"></a>

                                                                                            <video
                                                                                                id="mayosisplayergrid"
                                                                                                poster="#" controls
                                                                                                data-play="hover">
                                                                                                <source
                                                                                                    src="https://vz-ec4ee6c7-2cb.b-cdn.net/187dbff7-81a5-40d0-b2da-72d391266f93/play_720p.mp4"
                                                                                                    type="video/mp4" />
                                                                                            </video>

                                                                                            <div
                                                                                                class="video-inner-main">


                                                                                            </div>
                                                                                            <div class="clearfix"></div>
                                                                                        </div>








                                                                                        <figcaption
                                                                                            class="thumb-caption">
                                                                                            <div
                                                                                                class="overlay_content_center">


                                                                                                <div
                                                                                                    class="product_hover_details_button">
                                                                                                    <a href="video/raw-footage-of-london-cityscape-from-mile-end-stratford-aerial/index.html"
                                                                                                        class="button-fill-color">View
                                                                                                        Details</a>
                                                                                                </div>


                                                                                            </div>
                                                                                        </figcaption>

                                                                                    </div>
                                                                                </figure>
                                                                                <div class="product-meta">

                                                                                    <div class="product-tag">

                                                                                        <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/187dbff7-81a5-40d0-b2da-72d391266f93/play_720p.mp4"
                                                                                            class="mayosis-play--button-video icon-play"
                                                                                            data-lity>
                                                                                        </a>

                                                                                        <h4 class="product-title"><a
                                                                                                href="video/raw-footage-of-london-cityscape-from-mile-end-stratford-aerial/index.html">
                                                                                                Raw Footage Of London
                                                                                                Cityscape From Mile End,
                                                                                                Stratford, Aerial </a>
                                                                                        </h4>





                                                                                    </div>

                                                                                    <div class="count-download">

                                                                                        <div
                                                                                            class="product-price promo_price">
                                                                                            <span class="edd_price"
                                                                                                id="edd_price_8228">&#36;60.00</span>
                                                                                        </div>

                                                                                    </div>

                                                                                    <div class="clearfix"></div>


                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="mayo-page-product">
                                                            </div>
                                                        </div>
                                                        <div class="elementor-element elementor-element-e151cb0 mayosis-mobile-align-center mayosis-align-center elementor-widget elementor-widget-mayosis-single-button"
                                                            data-id="e151cb0" data-element_type="widget"
                                                            data-widget_type="mayosis-single-button.default">
                                                            <div class="elementor-widget-container">

                                                                <!-- Element Code start -->
                                                                <div class="elementor-button-area">
                                                                    <a class="custombuttonmain btn btn-primary btn-lg browse-more single_dm_btn"
                                                                        href="all-stock-videos/index.html"
                                                                        target="_self">Explore More <i class=""></i></a>
                                                                </div>


                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                        </section>

                        <section data-particle_enable="false" data-particle-mobile-disabled="false"
                            class="elementor-section elementor-top-section elementor-element elementor-element-f0bf11b elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="f0bf11b" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-51ab3e6 shadow-box"
                                        data-id="51ab3e6" data-element_type="column"
                                        data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-cf2348d elementor-widget-mobile__width-initial elementor-absolute elementor-widget elementor-widget-heading"
                                                    data-id="cf2348d" data-element_type="widget"
                                                    data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h1 class="elementor-heading-title elementor-size-default">
                                                            Subscribe To Get Discounts, Updates & More</h1>
                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-405c79b elementor-widget elementor-widget-text-editor"
                                                    data-id="405c79b" data-element_type="widget"
                                                    data-widget_type="text-editor.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-text-editor elementor-clearfix">
                                                            <div role="form" class="wpcf7" id="wpcf7-f83-p24-o1"
                                                                lang="en-US" dir="ltr">
                                                                <div class="screen-reader-response">
                                                                    <p role="status" aria-live="polite"
                                                                        aria-atomic="true"></p>
                                                                    <ul></ul>
                                                                </div>
                                                                <form
                                                                    action="https://africandronestock.com/#wpcf7-f83-p24-o1"
                                                                    method="post" class="wpcf7-form init"
                                                                    novalidate="novalidate" data-status="init">
                                                                    <div style="display: none;">
                                                                        <input type="hidden" name="_wpcf7" value="83" />
                                                                        <input type="hidden" name="_wpcf7_version"
                                                                            value="5.4.1" />
                                                                        <input type="hidden" name="_wpcf7_locale"
                                                                            value="en_US" />
                                                                        <input type="hidden" name="_wpcf7_unit_tag"
                                                                            value="wpcf7-f83-p24-o1" />
                                                                        <input type="hidden"
                                                                            name="_wpcf7_container_post" value="24" />
                                                                        <input type="hidden"
                                                                            name="_wpcf7_posted_data_hash" value="" />
                                                                    </div>
                                                                    <div
                                                                        class="input-group subscribe_form_dm solid-input">
                                                                        <span
                                                                            class="wpcf7-form-control-wrap email"><input
                                                                                type="email" name="email" value=""
                                                                                size="40"
                                                                                class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-email form-control email-attach-mayo"
                                                                                aria-invalid="false"
                                                                                placeholder="Your Email Address" /></span><br />
                                                                        <span class="input-group-addon subscribe-button"
                                                                            id="basic-addon2"><input type="submit"
                                                                                value="Submit"
                                                                                class="wpcf7-form-control wpcf7-submit btn btn-lg subscribe-button subscribe-button-attach" /></span>
                                                                    </div>
                                                                    <div class="wpcf7-response-output"
                                                                        aria-hidden="true"></div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section data-particle_enable="false" data-particle-mobile-disabled="false"
                            class="elementor-section elementor-top-section elementor-element elementor-element-e2a1a18 elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                            data-id="e2a1a18" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-768ee27"
                                        data-id="768ee27" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-fe22c4d elementor-widget elementor-widget-mayosis-edd-featured"
                                                    data-id="fe22c4d" data-element_type="widget"
                                                    data-widget_type="mayosis-edd-featured.default">
                                                    <div class="elementor-widget-container">


                                                        <div class="edd_fetured_ark">

                                                            <div class="full--grid-elementor">
                                                                <div class="title--box--full"
                                                                    style="margin-bottom:20px;">
                                                                    <div class="title--promo--box">
                                                                        <h3 class="section-title">BEST SELLING VIDEOS
                                                                        </h3>
                                                                    </div>

                                                                    <div class="title--button--box">
                                                                    </div>
                                                                </div>

                                                                <div class="row fix">

                                                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                                                        <div
                                                                            class="post-11622 download type-download status-publish format-video hentry download_category-cityscape download_tag-architectural download_tag-architecture download_tag-banks download_tag-building download_tag-buildings download_tag-canary-water download_tag-capital-city-panorama download_tag-cars download_tag-city download_tag-cityscape download_tag-day download_tag-dockland download_tag-downtown download_tag-dust download_tag-england download_tag-eu download_tag-evening download_tag-finance download_tag-glass-buildings-city-aerial download_tag-high-angle-view download_tag-high-buildings download_tag-high-rise download_tag-high-street download_tag-landscape download_tag-london-city download_tag-office-buildings download_tag-organisation download_tag-rich-city download_tag-road download_tag-skyline download_tag-skyscraper download_tag-sundown download_tag-sunset download_tag-technology download_tag-tourist download_tag-uk download_tag-urban edd-download edd-download-cat-cityscape edd-download-tag-architectural edd-download-tag-architecture edd-download-tag-banks edd-download-tag-building edd-download-tag-buildings edd-download-tag-canary-water edd-download-tag-capital-city-panorama edd-download-tag-cars edd-download-tag-city edd-download-tag-cityscape edd-download-tag-day edd-download-tag-dockland edd-download-tag-downtown edd-download-tag-dust edd-download-tag-england edd-download-tag-eu edd-download-tag-evening edd-download-tag-finance edd-download-tag-glass-buildings-city-aerial edd-download-tag-high-angle-view edd-download-tag-high-buildings edd-download-tag-high-rise edd-download-tag-high-street edd-download-tag-landscape edd-download-tag-london-city edd-download-tag-office-buildings edd-download-tag-organisation edd-download-tag-rich-city edd-download-tag-road edd-download-tag-skyline edd-download-tag-skyscraper edd-download-tag-sundown edd-download-tag-sunset edd-download-tag-technology edd-download-tag-tourist edd-download-tag-uk edd-download-tag-urban">
                                                                            <div class="grid_dm group edge">
                                                                                <div class="product-box"
                                                                                    style="position: relative;">
                                                                                    <div
                                                                                        style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                        <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                            style="height: 30px;"
                                                                                            alt="Logo" />
                                                                                    </div>
                                                                                    <div
                                                                                        class="wrap-ribbon left-edge point lblue">
                                                                                        <span>MOST SOLD</span></div>
                                                                                    <figure class="mayosis-fade-in">



                                                                                        <div
                                                                                            class="mayosis--video--box">
                                                                                            <div
                                                                                                class="video-inner-box-promo">
                                                                                                <a href="video/wide-angle-aerial-of-the-canary-wharf-buildings-in-london/index.html"
                                                                                                    class="mayosis-video-url"></a>

                                                                                                <video
                                                                                                    id="mayosisplayergrid"
                                                                                                    poster="#" controls
                                                                                                    data-play="hover">
                                                                                                    <source
                                                                                                        src="https://vz-ec4ee6c7-2cb.b-cdn.net/46e931fe-bd53-4b3c-b054-30a010a18046/play_720p.mp4"
                                                                                                        type="video/mp4" />
                                                                                                </video>


                                                                                                <div
                                                                                                    class="video-inner-main">

                                                                                                </div>
                                                                                                <div class="clearfix">
                                                                                                </div>
                                                                                            </div>







                                                                                            <figcaption
                                                                                                class="thumb-caption">
                                                                                                <div
                                                                                                    class="overlay_content_center">


                                                                                                    <div
                                                                                                        class="product_hover_details_button">
                                                                                                        <a href="video/wide-angle-aerial-of-the-canary-wharf-buildings-in-london/index.html"
                                                                                                            class="button-fill-color">View
                                                                                                            Details</a>
                                                                                                    </div>


                                                                                                </div>
                                                                                            </figcaption>

                                                                                        </div>
                                                                                    </figure>
                                                                                    <div class="product-meta">

                                                                                        <div class="product-tag">

                                                                                            <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/46e931fe-bd53-4b3c-b054-30a010a18046/play_720p.mp4"
                                                                                                class="mayosis-play--button-video icon-play"
                                                                                                data-lity>
                                                                                            </a>

                                                                                            <h4 class="product-title"><a
                                                                                                    href="video/wide-angle-aerial-of-the-canary-wharf-buildings-in-london/index.html">
                                                                                                    Wide Angle Aerial Of
                                                                                                    The Canary Wharf
                                                                                                    Buildings In London
                                                                                                </a></h4>





                                                                                        </div>

                                                                                        <div class="count-download">

                                                                                            <div
                                                                                                class="product-price promo_price">
                                                                                                <span class="edd_price"
                                                                                                    id="edd_price_11622">&#36;70.00</span>
                                                                                            </div>

                                                                                        </div>

                                                                                        <div class="clearfix"></div>

                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                                                        <div
                                                                            class="post-10747 download type-download status-publish format-video hentry download_category-nature download_tag-cars download_tag-christian-cemetery download_tag-christian-cross-on-cemetery download_tag-christian-symbols download_tag-church-yard download_tag-coffin download_tag-dead download_tag-death download_tag-funeral download_tag-grave download_tag-grave-stone download_tag-graves download_tag-grief download_tag-ground download_tag-headstone download_tag-memorial-cemetery download_tag-memorial-site download_tag-people-at-the-cemetery download_tag-quiet-cemetery download_tag-r-i-p download_tag-rest-in-peace download_tag-scary download_tag-stone download_tag-tombstones edd-download edd-download-cat-nature edd-download-tag-cars edd-download-tag-christian-cemetery edd-download-tag-christian-cross-on-cemetery edd-download-tag-christian-symbols edd-download-tag-church-yard edd-download-tag-coffin edd-download-tag-dead edd-download-tag-death edd-download-tag-funeral edd-download-tag-grave edd-download-tag-grave-stone edd-download-tag-graves edd-download-tag-grief edd-download-tag-ground edd-download-tag-headstone edd-download-tag-memorial-cemetery edd-download-tag-memorial-site edd-download-tag-people-at-the-cemetery edd-download-tag-quiet-cemetery edd-download-tag-r-i-p edd-download-tag-rest-in-peace edd-download-tag-scary edd-download-tag-stone edd-download-tag-tombstones">
                                                                            <div class="grid_dm group edge">
                                                                                <div class="product-box"
                                                                                    style="position: relative;">
                                                                                    <div
                                                                                        style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                        <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                            style="height: 30px;"
                                                                                            alt="Logo" />
                                                                                    </div>
                                                                                    <div
                                                                                        class="wrap-ribbon left-edge point lblue">
                                                                                        <span>MOST SOLD</span></div>
                                                                                    <figure class="mayosis-fade-in">



                                                                                        <div
                                                                                            class="mayosis--video--box">
                                                                                            <div
                                                                                                class="video-inner-box-promo">
                                                                                                <a href="video/europe-cemetery-aerial/index.html"
                                                                                                    class="mayosis-video-url"></a>

                                                                                                <video
                                                                                                    id="mayosisplayergrid"
                                                                                                    poster="#" controls
                                                                                                    data-play="hover">
                                                                                                    <source
                                                                                                        src="https://vz-ec4ee6c7-2cb.b-cdn.net/22152278-1d45-410f-801b-e0a558cdc499/play_720p.mp4"
                                                                                                        type="video/mp4" />
                                                                                                </video>


                                                                                                <div
                                                                                                    class="video-inner-main">

                                                                                                </div>
                                                                                                <div class="clearfix">
                                                                                                </div>
                                                                                            </div>







                                                                                            <figcaption
                                                                                                class="thumb-caption">
                                                                                                <div
                                                                                                    class="overlay_content_center">


                                                                                                    <div
                                                                                                        class="product_hover_details_button">
                                                                                                        <a href="video/europe-cemetery-aerial/index.html"
                                                                                                            class="button-fill-color">View
                                                                                                            Details</a>
                                                                                                    </div>


                                                                                                </div>
                                                                                            </figcaption>

                                                                                        </div>
                                                                                    </figure>
                                                                                    <div class="product-meta">

                                                                                        <div class="product-tag">

                                                                                            <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/22152278-1d45-410f-801b-e0a558cdc499/play_720p.mp4"
                                                                                                class="mayosis-play--button-video icon-play"
                                                                                                data-lity>
                                                                                            </a>

                                                                                            <h4 class="product-title"><a
                                                                                                    href="video/europe-cemetery-aerial/index.html">
                                                                                                    Europe Cemetery
                                                                                                    Aerial </a></h4>





                                                                                        </div>

                                                                                        <div class="count-download">

                                                                                            <div
                                                                                                class="product-price promo_price">
                                                                                                <span class="edd_price"
                                                                                                    id="edd_price_10747">&#36;60.00</span>
                                                                                            </div>

                                                                                        </div>

                                                                                        <div class="clearfix"></div>

                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                                                        <div
                                                                            class="post-9920 download type-download status-publish format-video hentry download_category-sunset-cityscape download_tag-aerial download_tag-architecture download_tag-building download_tag-business download_tag-cars download_tag-central download_tag-city download_tag-city-buildings download_tag-cityscape download_tag-commercial download_tag-corporate download_tag-economy download_tag-estate download_tag-expensive-city-transport download_tag-famous download_tag-financial download_tag-financial-city-urban download_tag-fortune download_tag-high-rise-buildings download_tag-high-street download_tag-market download_tag-metropolitan download_tag-office-buildings download_tag-offices download_tag-river download_tag-road download_tag-skyline download_tag-skyscrapers download_tag-stock-exchange download_tag-street download_tag-success download_tag-tall-buildings download_tag-tallest download_tag-travel download_tag-world-buildings-skyscraper edd-download edd-download-cat-sunset-cityscape edd-download-tag-aerial edd-download-tag-architecture edd-download-tag-building edd-download-tag-business edd-download-tag-cars edd-download-tag-central edd-download-tag-city edd-download-tag-city-buildings edd-download-tag-cityscape edd-download-tag-commercial edd-download-tag-corporate edd-download-tag-economy edd-download-tag-estate edd-download-tag-expensive-city-transport edd-download-tag-famous edd-download-tag-financial edd-download-tag-financial-city-urban edd-download-tag-fortune edd-download-tag-high-rise-buildings edd-download-tag-high-street edd-download-tag-market edd-download-tag-metropolitan edd-download-tag-office-buildings edd-download-tag-offices edd-download-tag-river edd-download-tag-road edd-download-tag-skyline edd-download-tag-skyscrapers edd-download-tag-stock-exchange edd-download-tag-street edd-download-tag-success edd-download-tag-tall-buildings edd-download-tag-tallest edd-download-tag-travel edd-download-tag-world-buildings-skyscraper">
                                                                            <div class="grid_dm group edge">
                                                                                <div class="product-box"
                                                                                    style="position: relative;">
                                                                                    <div
                                                                                        style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                        <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                            style="height: 30px;"
                                                                                            alt="Logo" />
                                                                                    </div>
                                                                                    <div
                                                                                        class="wrap-ribbon left-edge point lblue">
                                                                                        <span>MOST SOLD</span></div>
                                                                                    <figure class="mayosis-fade-in">



                                                                                        <div
                                                                                            class="mayosis--video--box">
                                                                                            <div
                                                                                                class="video-inner-box-promo">
                                                                                                <a href="video/aerial-view-of-london-canary-wharf-financial-district-united-kingdom-at-sunset/index.html"
                                                                                                    class="mayosis-video-url"></a>

                                                                                                <video
                                                                                                    id="mayosisplayergrid"
                                                                                                    poster="#" controls
                                                                                                    data-play="hover">
                                                                                                    <source
                                                                                                        src="https://vz-ec4ee6c7-2cb.b-cdn.net/2dbc05e6-693c-4a70-b5a4-8f7e3069adf4/play_720p.mp4"
                                                                                                        type="video/mp4" />
                                                                                                </video>


                                                                                                <div
                                                                                                    class="video-inner-main">

                                                                                                </div>
                                                                                                <div class="clearfix">
                                                                                                </div>
                                                                                            </div>







                                                                                            <figcaption
                                                                                                class="thumb-caption">
                                                                                                <div
                                                                                                    class="overlay_content_center">


                                                                                                    <div
                                                                                                        class="product_hover_details_button">
                                                                                                        <a href="video/aerial-view-of-london-canary-wharf-financial-district-united-kingdom-at-sunset/index.html"
                                                                                                            class="button-fill-color">View
                                                                                                            Details</a>
                                                                                                    </div>


                                                                                                </div>
                                                                                            </figcaption>

                                                                                        </div>
                                                                                    </figure>
                                                                                    <div class="product-meta">

                                                                                        <div class="product-tag">

                                                                                            <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/2dbc05e6-693c-4a70-b5a4-8f7e3069adf4/play_720p.mp4"
                                                                                                class="mayosis-play--button-video icon-play"
                                                                                                data-lity>
                                                                                            </a>

                                                                                            <h4 class="product-title"><a
                                                                                                    href="video/aerial-view-of-london-canary-wharf-financial-district-united-kingdom-at-sunset/index.html">
                                                                                                    Aerial View Of
                                                                                                    London, Canary
                                                                                                    Wharf, Financial
                                                                                                    District, United
                                                                                                    Kingdom At Sunset
                                                                                                </a></h4>





                                                                                        </div>

                                                                                        <div class="count-download">

                                                                                            <div
                                                                                                class="product-price promo_price">
                                                                                                <span class="edd_price"
                                                                                                    id="edd_price_9920">&#36;70.00</span>
                                                                                            </div>

                                                                                        </div>

                                                                                        <div class="clearfix"></div>

                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                                                        <div
                                                                            class="post-9915 download type-download status-publish format-video hentry download_category-sunset-cityscape download_tag-architectural download_tag-architecture download_tag-banks download_tag-building download_tag-buildings download_tag-canary-water download_tag-capital-city-panorama download_tag-cars download_tag-city download_tag-cityscape download_tag-day download_tag-dockland download_tag-downtown download_tag-dust download_tag-england download_tag-eu download_tag-evening download_tag-finance download_tag-glass-buildings-city-aerial download_tag-high-angle-view download_tag-high-buildings download_tag-high-rise download_tag-high-street download_tag-landscape download_tag-london-city download_tag-office-buildings download_tag-organisation download_tag-rich-city download_tag-road download_tag-skyline download_tag-skyscraper download_tag-sundown download_tag-sunset download_tag-technology download_tag-tourist download_tag-uk download_tag-urban edd-download edd-download-cat-sunset-cityscape edd-download-tag-architectural edd-download-tag-architecture edd-download-tag-banks edd-download-tag-building edd-download-tag-buildings edd-download-tag-canary-water edd-download-tag-capital-city-panorama edd-download-tag-cars edd-download-tag-city edd-download-tag-cityscape edd-download-tag-day edd-download-tag-dockland edd-download-tag-downtown edd-download-tag-dust edd-download-tag-england edd-download-tag-eu edd-download-tag-evening edd-download-tag-finance edd-download-tag-glass-buildings-city-aerial edd-download-tag-high-angle-view edd-download-tag-high-buildings edd-download-tag-high-rise edd-download-tag-high-street edd-download-tag-landscape edd-download-tag-london-city edd-download-tag-office-buildings edd-download-tag-organisation edd-download-tag-rich-city edd-download-tag-road edd-download-tag-skyline edd-download-tag-skyscraper edd-download-tag-sundown edd-download-tag-sunset edd-download-tag-technology edd-download-tag-tourist edd-download-tag-uk edd-download-tag-urban">
                                                                            <div class="grid_dm group edge">
                                                                                <div class="product-box"
                                                                                    style="position: relative;">
                                                                                    <div
                                                                                        style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                        <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                            style="height: 30px;"
                                                                                            alt="Logo" />
                                                                                    </div>
                                                                                    <div
                                                                                        class="wrap-ribbon left-edge point lblue">
                                                                                        <span>MOST SOLD</span></div>
                                                                                    <figure class="mayosis-fade-in">



                                                                                        <div
                                                                                            class="mayosis--video--box">
                                                                                            <div
                                                                                                class="video-inner-box-promo">
                                                                                                <a href="video/aerial-view-of-london-uk-canary-wharf-business-district-east-london-united-kingdom-soft-light/index.html"
                                                                                                    class="mayosis-video-url"></a>

                                                                                                <video
                                                                                                    id="mayosisplayergrid"
                                                                                                    poster="#" controls
                                                                                                    data-play="hover">
                                                                                                    <source
                                                                                                        src="https://vz-ec4ee6c7-2cb.b-cdn.net/1d595bad-285f-4758-8466-caf7f15cc969/play_720p.mp4"
                                                                                                        type="video/mp4" />
                                                                                                </video>


                                                                                                <div
                                                                                                    class="video-inner-main">

                                                                                                </div>
                                                                                                <div class="clearfix">
                                                                                                </div>
                                                                                            </div>







                                                                                            <figcaption
                                                                                                class="thumb-caption">
                                                                                                <div
                                                                                                    class="overlay_content_center">


                                                                                                    <div
                                                                                                        class="product_hover_details_button">
                                                                                                        <a href="video/aerial-view-of-london-uk-canary-wharf-business-district-east-london-united-kingdom-soft-light/index.html"
                                                                                                            class="button-fill-color">View
                                                                                                            Details</a>
                                                                                                    </div>


                                                                                                </div>
                                                                                            </figcaption>

                                                                                        </div>
                                                                                    </figure>
                                                                                    <div class="product-meta">

                                                                                        <div class="product-tag">

                                                                                            <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/1d595bad-285f-4758-8466-caf7f15cc969/play_720p.mp4"
                                                                                                class="mayosis-play--button-video icon-play"
                                                                                                data-lity>
                                                                                            </a>

                                                                                            <h4 class="product-title"><a
                                                                                                    href="video/aerial-view-of-london-uk-canary-wharf-business-district-east-london-united-kingdom-soft-light/index.html">
                                                                                                    Aerial View Of
                                                                                                    London Uk, Canary
                                                                                                    Wharf, Business
                                                                                                    District, East
                                                                                                    London, United
                                                                                                    Kingdom, Soft Light
                                                                                                </a></h4>





                                                                                        </div>

                                                                                        <div class="count-download">

                                                                                            <div
                                                                                                class="product-price promo_price">
                                                                                                <span class="edd_price"
                                                                                                    id="edd_price_9915">&#36;70.00</span>
                                                                                            </div>

                                                                                        </div>

                                                                                        <div class="clearfix"></div>

                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                                                        <div
                                                                            class="post-9152 download type-download status-publish format-video hentry download_category-nature download_tag-beautiful-park download_tag-cinematic download_tag-environment download_tag-green-field download_tag-green-filed-in-spring download_tag-green-grass download_tag-green-lawn download_tag-green-park download_tag-nature download_tag-panoramic download_tag-quiet-green-filed download_tag-quiet-green-park download_tag-quiet-nature download_tag-scenic download_tag-serene-environment download_tag-spring download_tag-trees edd-download edd-download-cat-nature edd-download-tag-beautiful-park edd-download-tag-cinematic edd-download-tag-environment edd-download-tag-green-field edd-download-tag-green-filed-in-spring edd-download-tag-green-grass edd-download-tag-green-lawn edd-download-tag-green-park edd-download-tag-nature edd-download-tag-panoramic edd-download-tag-quiet-green-filed edd-download-tag-quiet-green-park edd-download-tag-quiet-nature edd-download-tag-scenic edd-download-tag-serene-environment edd-download-tag-spring edd-download-tag-trees">
                                                                            <div class="grid_dm group edge">
                                                                                <div class="product-box"
                                                                                    style="position: relative;">
                                                                                    <div
                                                                                        style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                        <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                            style="height: 30px;"
                                                                                            alt="Logo" />
                                                                                    </div>
                                                                                    <div
                                                                                        class="wrap-ribbon left-edge point lblue">
                                                                                        <span>MOST SOLD</span></div>
                                                                                    <figure class="mayosis-fade-in">



                                                                                        <div
                                                                                            class="mayosis--video--box">
                                                                                            <div
                                                                                                class="video-inner-box-promo">
                                                                                                <a href="video/backwards-reveal-of-london-most-beastiful-park-aerial/index.html"
                                                                                                    class="mayosis-video-url"></a>

                                                                                                <video
                                                                                                    id="mayosisplayergrid"
                                                                                                    poster="#" controls
                                                                                                    data-play="hover">
                                                                                                    <source
                                                                                                        src="https://vz-ec4ee6c7-2cb.b-cdn.net/a0107443-8381-460b-a0d8-95efa2f915f5/play_720p.mp4"
                                                                                                        type="video/mp4" />
                                                                                                </video>


                                                                                                <div
                                                                                                    class="video-inner-main">

                                                                                                </div>
                                                                                                <div class="clearfix">
                                                                                                </div>
                                                                                            </div>







                                                                                            <figcaption
                                                                                                class="thumb-caption">
                                                                                                <div
                                                                                                    class="overlay_content_center">


                                                                                                    <div
                                                                                                        class="product_hover_details_button">
                                                                                                        <a href="video/backwards-reveal-of-london-most-beastiful-park-aerial/index.html"
                                                                                                            class="button-fill-color">View
                                                                                                            Details</a>
                                                                                                    </div>


                                                                                                </div>
                                                                                            </figcaption>

                                                                                        </div>
                                                                                    </figure>
                                                                                    <div class="product-meta">

                                                                                        <div class="product-tag">

                                                                                            <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/a0107443-8381-460b-a0d8-95efa2f915f5/play_720p.mp4"
                                                                                                class="mayosis-play--button-video icon-play"
                                                                                                data-lity>
                                                                                            </a>

                                                                                            <h4 class="product-title"><a
                                                                                                    href="video/backwards-reveal-of-london-most-beastiful-park-aerial/index.html">
                                                                                                    Backwards Reveal Of
                                                                                                    London Most
                                                                                                    Beastiful Park,
                                                                                                    Aerial </a></h4>





                                                                                        </div>

                                                                                        <div class="count-download">

                                                                                            <div
                                                                                                class="product-price promo_price">
                                                                                                <span class="edd_price"
                                                                                                    id="edd_price_9152">&#36;60.00</span>
                                                                                            </div>

                                                                                        </div>

                                                                                        <div class="clearfix"></div>

                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                                                        <div
                                                                            class="post-8427 download type-download status-publish format-video hentry download_category-cityscape download_tag-architecture download_tag-building download_tag-central download_tag-city download_tag-cityscape download_tag-corporate download_tag-economy download_tag-estate download_tag-famous download_tag-fortune download_tag-market download_tag-metropolitan download_tag-office-buildings download_tag-offices download_tag-skyline download_tag-skyscrapers download_tag-stock-exchange download_tag-success download_tag-tallest edd-download edd-download-cat-cityscape edd-download-tag-architecture edd-download-tag-building edd-download-tag-central edd-download-tag-city edd-download-tag-cityscape edd-download-tag-corporate edd-download-tag-economy edd-download-tag-estate edd-download-tag-famous edd-download-tag-fortune edd-download-tag-market edd-download-tag-metropolitan edd-download-tag-office-buildings edd-download-tag-offices edd-download-tag-skyline edd-download-tag-skyscrapers edd-download-tag-stock-exchange edd-download-tag-success edd-download-tag-tallest">
                                                                            <div class="grid_dm group edge">
                                                                                <div class="product-box"
                                                                                    style="position: relative;">
                                                                                    <div
                                                                                        style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                        <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                            style="height: 30px;"
                                                                                            alt="Logo" />
                                                                                    </div>
                                                                                    <div
                                                                                        class="wrap-ribbon left-edge point lblue">
                                                                                        <span>MOST SOLD</span></div>
                                                                                    <figure class="mayosis-fade-in">



                                                                                        <div
                                                                                            class="mayosis--video--box">
                                                                                            <div
                                                                                                class="video-inner-box-promo">
                                                                                                <a href="video/uk-englands-suburban-bird-view/index.html"
                                                                                                    class="mayosis-video-url"></a>

                                                                                                <video
                                                                                                    id="mayosisplayergrid"
                                                                                                    poster="#" controls
                                                                                                    data-play="hover">
                                                                                                    <source
                                                                                                        src="https://vz-ec4ee6c7-2cb.b-cdn.net/b16ad183-7ae0-4588-9538-fa8827c52cef/play_720p.mp4"
                                                                                                        type="video/mp4" />
                                                                                                </video>


                                                                                                <div
                                                                                                    class="video-inner-main">

                                                                                                </div>
                                                                                                <div class="clearfix">
                                                                                                </div>
                                                                                            </div>







                                                                                            <figcaption
                                                                                                class="thumb-caption">
                                                                                                <div
                                                                                                    class="overlay_content_center">


                                                                                                    <div
                                                                                                        class="product_hover_details_button">
                                                                                                        <a href="video/uk-englands-suburban-bird-view/index.html"
                                                                                                            class="button-fill-color">View
                                                                                                            Details</a>
                                                                                                    </div>


                                                                                                </div>
                                                                                            </figcaption>

                                                                                        </div>
                                                                                    </figure>
                                                                                    <div class="product-meta">

                                                                                        <div class="product-tag">

                                                                                            <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/b16ad183-7ae0-4588-9538-fa8827c52cef/play_720p.mp4"
                                                                                                class="mayosis-play--button-video icon-play"
                                                                                                data-lity>
                                                                                            </a>

                                                                                            <h4 class="product-title"><a
                                                                                                    href="video/uk-englands-suburban-bird-view/index.html">
                                                                                                    Uk, England&#8217;s
                                                                                                    Suburban Bird View
                                                                                                </a></h4>





                                                                                        </div>

                                                                                        <div class="count-download">

                                                                                            <div
                                                                                                class="product-price promo_price">
                                                                                                <span class="edd_price"
                                                                                                    id="edd_price_8427">&#36;60.00</span>
                                                                                            </div>

                                                                                        </div>

                                                                                        <div class="clearfix"></div>

                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                                                        <div
                                                                            class="post-8425 download type-download status-publish format-video hentry download_category-cityscape download_tag-banks download_tag-business-buildings download_tag-canada download_tag-city-capital download_tag-complex-design download_tag-downtown download_tag-europe-capital download_tag-financial-district download_tag-futuristic download_tag-headquarters download_tag-international download_tag-tallest-skyscrapers edd-download edd-download-cat-cityscape edd-download-tag-banks edd-download-tag-business-buildings edd-download-tag-canada edd-download-tag-city-capital edd-download-tag-complex-design edd-download-tag-downtown edd-download-tag-europe-capital edd-download-tag-financial-district edd-download-tag-futuristic edd-download-tag-headquarters edd-download-tag-international edd-download-tag-tallest-skyscrapers">
                                                                            <div class="grid_dm group edge">
                                                                                <div class="product-box"
                                                                                    style="position: relative;">
                                                                                    <div
                                                                                        style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                        <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                            style="height: 30px;"
                                                                                            alt="Logo" />
                                                                                    </div>
                                                                                    <div
                                                                                        class="wrap-ribbon left-edge point lblue">
                                                                                        <span>MOST SOLD</span></div>
                                                                                    <figure class="mayosis-fade-in">



                                                                                        <div
                                                                                            class="mayosis--video--box">
                                                                                            <div
                                                                                                class="video-inner-box-promo">
                                                                                                <a href="video/downtown-urban-area-forward-aerial-view-with-skyscrapers/index.html"
                                                                                                    class="mayosis-video-url"></a>

                                                                                                <video
                                                                                                    id="mayosisplayergrid"
                                                                                                    poster="#" controls
                                                                                                    data-play="hover">
                                                                                                    <source
                                                                                                        src="https://vz-ec4ee6c7-2cb.b-cdn.net/9c225114-15d7-42f2-a992-4b06f15ed665/play_720p.mp4"
                                                                                                        type="video/mp4" />
                                                                                                </video>


                                                                                                <div
                                                                                                    class="video-inner-main">

                                                                                                </div>
                                                                                                <div class="clearfix">
                                                                                                </div>
                                                                                            </div>







                                                                                            <figcaption
                                                                                                class="thumb-caption">
                                                                                                <div
                                                                                                    class="overlay_content_center">


                                                                                                    <div
                                                                                                        class="product_hover_details_button">
                                                                                                        <a href="video/downtown-urban-area-forward-aerial-view-with-skyscrapers/index.html"
                                                                                                            class="button-fill-color">View
                                                                                                            Details</a>
                                                                                                    </div>


                                                                                                </div>
                                                                                            </figcaption>

                                                                                        </div>
                                                                                    </figure>
                                                                                    <div class="product-meta">

                                                                                        <div class="product-tag">

                                                                                            <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/9c225114-15d7-42f2-a992-4b06f15ed665/play_720p.mp4"
                                                                                                class="mayosis-play--button-video icon-play"
                                                                                                data-lity>
                                                                                            </a>

                                                                                            <h4 class="product-title"><a
                                                                                                    href="video/downtown-urban-area-forward-aerial-view-with-skyscrapers/index.html">
                                                                                                    Downtown Urban Area,
                                                                                                    Forward Aerial View
                                                                                                    With Skyscrapers
                                                                                                </a></h4>





                                                                                        </div>

                                                                                        <div class="count-download">

                                                                                            <div
                                                                                                class="product-price promo_price">
                                                                                                <span class="edd_price"
                                                                                                    id="edd_price_8425">&#36;60.00</span>
                                                                                            </div>

                                                                                        </div>

                                                                                        <div class="clearfix"></div>

                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                                                        <div
                                                                            class="post-8338 download type-download status-publish format-video hentry download_category-timelapse download_tag-beautiful-sky-hyperlapse download_tag-busy-road-hyper-lapse download_tag-cityscape download_tag-cityscape-hyper-lapse download_tag-colourful-sky download_tag-fast download_tag-moving-sky download_tag-night-time-lapse download_tag-sunset-hyper-lapse download_tag-sunset-sky-hyperlapse download_tag-sunset-time-lapse edd-download edd-download-cat-timelapse edd-download-tag-beautiful-sky-hyperlapse edd-download-tag-busy-road-hyper-lapse edd-download-tag-cityscape edd-download-tag-cityscape-hyper-lapse edd-download-tag-colourful-sky edd-download-tag-fast edd-download-tag-moving-sky edd-download-tag-night-time-lapse edd-download-tag-sunset-hyper-lapse edd-download-tag-sunset-sky-hyperlapse edd-download-tag-sunset-time-lapse">
                                                                            <div class="grid_dm group edge">
                                                                                <div class="product-box"
                                                                                    style="position: relative;">
                                                                                    <div
                                                                                        style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                        <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                            style="height: 30px;"
                                                                                            alt="Logo" />
                                                                                    </div>
                                                                                    <div
                                                                                        class="wrap-ribbon left-edge point lblue">
                                                                                        <span>MOST SOLD</span></div>
                                                                                    <figure class="mayosis-fade-in">



                                                                                        <div
                                                                                            class="mayosis--video--box">
                                                                                            <div
                                                                                                class="video-inner-box-promo">
                                                                                                <a href="video/time-lapse-of-a-beautiful-green-city-park-with-amazing-colours-in-the-sky-aerial/index.html"
                                                                                                    class="mayosis-video-url"></a>

                                                                                                <video
                                                                                                    id="mayosisplayergrid"
                                                                                                    poster="#" controls
                                                                                                    data-play="hover">
                                                                                                    <source
                                                                                                        src="https://vz-ec4ee6c7-2cb.b-cdn.net/0cee1e15-4a3b-43e7-b3f0-c172a1efd20c/play_720p.mp4"
                                                                                                        type="video/mp4" />
                                                                                                </video>


                                                                                                <div
                                                                                                    class="video-inner-main">

                                                                                                </div>
                                                                                                <div class="clearfix">
                                                                                                </div>
                                                                                            </div>







                                                                                            <figcaption
                                                                                                class="thumb-caption">
                                                                                                <div
                                                                                                    class="overlay_content_center">


                                                                                                    <div
                                                                                                        class="product_hover_details_button">
                                                                                                        <a href="video/time-lapse-of-a-beautiful-green-city-park-with-amazing-colours-in-the-sky-aerial/index.html"
                                                                                                            class="button-fill-color">View
                                                                                                            Details</a>
                                                                                                    </div>


                                                                                                </div>
                                                                                            </figcaption>

                                                                                        </div>
                                                                                    </figure>
                                                                                    <div class="product-meta">

                                                                                        <div class="product-tag">

                                                                                            <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/0cee1e15-4a3b-43e7-b3f0-c172a1efd20c/play_720p.mp4"
                                                                                                class="mayosis-play--button-video icon-play"
                                                                                                data-lity>
                                                                                            </a>

                                                                                            <h4 class="product-title"><a
                                                                                                    href="video/time-lapse-of-a-beautiful-green-city-park-with-amazing-colours-in-the-sky-aerial/index.html">
                                                                                                    Time Lapse Of A
                                                                                                    Beautiful Green City
                                                                                                    Park With Amazing
                                                                                                    Colours In The Sky,
                                                                                                    Aerial </a></h4>





                                                                                        </div>

                                                                                        <div class="count-download">

                                                                                            <div
                                                                                                class="product-price promo_price">
                                                                                                <span class="edd_price"
                                                                                                    id="edd_price_8338">&#36;60.00</span>
                                                                                            </div>

                                                                                        </div>

                                                                                        <div class="clearfix"></div>

                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4 col-xs-12 col-sm-4">
                                                                        <div
                                                                            class="post-8322 download type-download status-publish format-video hentry download_category-timelapse download_tag-beautiful-sky-hyperlapse download_tag-busy-road-hyper-lapse download_tag-cityscape download_tag-cityscape-hyper-lapse download_tag-colourful-sky download_tag-fast download_tag-moving-cars download_tag-moving-sky download_tag-night-hyper-lapse download_tag-night-time-lapse download_tag-sunset-hyper-lapse download_tag-sunset-sky-hyperlapse download_tag-sunset-time-lapse edd-download edd-download-cat-timelapse edd-download-tag-beautiful-sky-hyperlapse edd-download-tag-busy-road-hyper-lapse edd-download-tag-cityscape edd-download-tag-cityscape-hyper-lapse edd-download-tag-colourful-sky edd-download-tag-fast edd-download-tag-moving-cars edd-download-tag-moving-sky edd-download-tag-night-hyper-lapse edd-download-tag-night-time-lapse edd-download-tag-sunset-hyper-lapse edd-download-tag-sunset-sky-hyperlapse edd-download-tag-sunset-time-lapse">
                                                                            <div class="grid_dm group edge">
                                                                                <div class="product-box"
                                                                                    style="position: relative;">
                                                                                    <div
                                                                                        style="position: absolute;bottom:50px;left:10px;z-index:1">
                                                                                        <img src="wp-content/themes/mayosis/images/waterMark.html"
                                                                                            style="height: 30px;"
                                                                                            alt="Logo" />
                                                                                    </div>
                                                                                    <div
                                                                                        class="wrap-ribbon left-edge point lblue">
                                                                                        <span>MOST SOLD</span></div>
                                                                                    <figure class="mayosis-fade-in">



                                                                                        <div
                                                                                            class="mayosis--video--box">
                                                                                            <div
                                                                                                class="video-inner-box-promo">
                                                                                                <a href="video/cityscape-with-red-lights-and-moving-cars-at-night-time-lapse-forward-reveal-aerial/index.html"
                                                                                                    class="mayosis-video-url"></a>

                                                                                                <video
                                                                                                    id="mayosisplayergrid"
                                                                                                    poster="#" controls
                                                                                                    data-play="hover">
                                                                                                    <source
                                                                                                        src="https://vz-ec4ee6c7-2cb.b-cdn.net/94614f79-7ff3-448b-8c91-5dade44d3f75/play_720p.mp4"
                                                                                                        type="video/mp4" />
                                                                                                </video>


                                                                                                <div
                                                                                                    class="video-inner-main">

                                                                                                </div>
                                                                                                <div class="clearfix">
                                                                                                </div>
                                                                                            </div>







                                                                                            <figcaption
                                                                                                class="thumb-caption">
                                                                                                <div
                                                                                                    class="overlay_content_center">


                                                                                                    <div
                                                                                                        class="product_hover_details_button">
                                                                                                        <a href="video/cityscape-with-red-lights-and-moving-cars-at-night-time-lapse-forward-reveal-aerial/index.html"
                                                                                                            class="button-fill-color">View
                                                                                                            Details</a>
                                                                                                    </div>


                                                                                                </div>
                                                                                            </figcaption>

                                                                                        </div>
                                                                                    </figure>
                                                                                    <div class="product-meta">

                                                                                        <div class="product-tag">

                                                                                            <a href="https://vz-ec4ee6c7-2cb.b-cdn.net/94614f79-7ff3-448b-8c91-5dade44d3f75/play_720p.mp4"
                                                                                                class="mayosis-play--button-video icon-play"
                                                                                                data-lity>
                                                                                            </a>

                                                                                            <h4 class="product-title"><a
                                                                                                    href="video/cityscape-with-red-lights-and-moving-cars-at-night-time-lapse-forward-reveal-aerial/index.html">
                                                                                                    Cityscape With Red
                                                                                                    Lights And Moving
                                                                                                    Cars At Night
                                                                                                    Time-lapse Forward
                                                                                                    Reveal Aerial </a>
                                                                                            </h4>





                                                                                        </div>

                                                                                        <div class="count-download">

                                                                                            <div
                                                                                                class="product-price promo_price">
                                                                                                <span class="edd_price"
                                                                                                    id="edd_price_8322">&#36;60.00</span>
                                                                                            </div>

                                                                                        </div>

                                                                                        <div class="clearfix"></div>

                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>



                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                        </section>

                        <section
                            class="has_mayosis_custom_bg_thumbnail elementor-section elementor-top-section elementor-element elementor-element-89b086e elementor-reverse-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            style="background:url('images/home_page_image.jpg');" data-particle_enable="false" data-particle-mobile-disabled="false"
                            data-id="89b086e" data-element_type="section"
                            data-settings="{&quot;background_background&quot;:&quot;slideshow&quot;,&quot;background_slideshow_gallery&quot;:[{&quot;id&quot;:10162,&quot;url&quot;:&quot;https:\/\/africandronestock.com\/wp-content\/uploads\/2021\/04\/frankfurt-1804481-2.jpg&quot;}],&quot;background_slideshow_loop&quot;:&quot;yes&quot;,&quot;background_slideshow_slide_duration&quot;:5000,&quot;background_slideshow_slide_transition&quot;:&quot;fade&quot;,&quot;background_slideshow_transition_duration&quot;:500}">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-aad8544"
                                        data-id="aad8544" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">

                                                <section data-particle_enable="false"
                                                    data-particle-mobile-disabled="false"
                                                    class="elementor-section elementor-inner-section elementor-element elementor-element-8749ec5 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                                    data-id="8749ec5" data-element_type="section">
                                                    <div class="elementor-container elementor-column-gap-default">
                                                        <div class="elementor-row">

                                                            <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-08ed2a1 shadow-box"
                                                                data-id="08ed2a1" data-element_type="column"
                                                                data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                                <div
                                                                    class="elementor-column-wrap elementor-element-populated">
                                                                    <div class="elementor-widget-wrap">
                                                                        <div class="elementor-element elementor-element-3ff7f70 shadow-bo elementor-widget elementor-widget-mayosis-counter"
                                                                            data-id="3ff7f70" data-element_type="widget"
                                                                            data-widget_type="mayosis-counter.default">
                                                                            <div class="elementor-widget-container">


                                                                                <!-- Element Code start -->
                                                                                <div class="counter-box">
                                                                                    <h4 class="statistic-counter">35841
                                                                                    </h4> <span
                                                                                        class="counter-suffix"></span>
                                                                                    <p class="mcounter_title_promo">
                                                                                        PREMIUM STOCKS</p>

                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-4c6a766 shadow-box"
                                                                data-id="4c6a766" data-element_type="column"
                                                                data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                                <div
                                                                    class="elementor-column-wrap elementor-element-populated">
                                                                    <div class="elementor-widget-wrap">
                                                                        <div class="elementor-element elementor-element-9afa1ac elementor-widget elementor-widget-mayosis-counter"
                                                                            data-id="9afa1ac" data-element_type="widget"
                                                                            data-widget_type="mayosis-counter.default">
                                                                            <div class="elementor-widget-container">


                                                                                <!-- Element Code start -->
                                                                                <div class="counter-box">
                                                                                    <h4 class="statistic-counter">17852
                                                                                    </h4> <span
                                                                                        class="counter-suffix"></span>
                                                                                    <p class="mcounter_title_promo">
                                                                                        TOTAL DOWNLOADS</p>

                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-3009d65 shadow-box"
                                                                data-id="3009d65" data-element_type="column"
                                                                data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                                <div
                                                                    class="elementor-column-wrap elementor-element-populated">
                                                                    <div class="elementor-widget-wrap">
                                                                        <div class="elementor-element elementor-element-5570bc5 elementor-widget elementor-widget-mayosis-counter"
                                                                            data-id="5570bc5" data-element_type="widget"
                                                                            data-widget_type="mayosis-counter.default">
                                                                            <div class="elementor-widget-container">


                                                                                <!-- Element Code start -->
                                                                                <div class="counter-box">
                                                                                    <h4 class="statistic-counter">1132
                                                                                    </h4> <span
                                                                                        class="counter-suffix"></span>
                                                                                    <p class="mcounter_title_promo">
                                                                                        EMAIL SUBSCRIBER</p>

                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section data-particle_enable="false" data-particle-mobile-disabled="false"
                            class="elementor-section elementor-top-section elementor-element elementor-element-aeff6c0 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="aeff6c0" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-bc4d91c"
                                        data-id="bc4d91c" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-95d64bb elementor-widget elementor-widget-mayosis-search-terms"
                                                    data-id="95d64bb" data-element_type="widget"
                                                    data-widget_type="mayosis-search-terms.default">
                                                    <div class="elementor-widget-container">

                                                        <div class="search--term--div ">
                                                            <h2 class="section-title">Search With Tags </h2>


                                                            <div class="search-term-style-five tag_widget_single">

                                                                <ul>
                                                                    <li><a href="search/1080/index.html"
                                                                            rel="nofollow">1080</a><a
                                                                            href="search/drone%2bview/index.html"
                                                                            rel="nofollow">drone view</a><a
                                                                            href="search/h/index.html"
                                                                            rel="nofollow">h</a><a
                                                                            href="search/aerials/index.html"
                                                                            rel="nofollow">aerials</a><a
                                                                            href="search/a%2bflock%2bof%2bbirds%2bflying%2bover%2ba%2bpond%2bwith%2bbeautiful%2bcityscape%2baerial%2c%2buk%2blondon-/index.html"
                                                                            rel="nofollow">a flock of birds flying over
                                                                            a pond with beautiful cityscape aerial, uk
                                                                            london-</a><a
                                                                            href="search/drone%2bdescends%2brevealing%2bstraight%2bcity%2bpathway/index.html"
                                                                            rel="nofollow">drone descends revealing
                                                                            straight city pathway</a><a
                                                                            href="search/bird%2beye%2bview%2bof%2bcar%2bpark/index.html"
                                                                            rel="nofollow">bird eye view of car
                                                                            park</a><a
                                                                            href="search/drone%2bvideos/index.html"
                                                                            rel="nofollow">drone videos</a><a
                                                                            href="search/videos/index.html"
                                                                            rel="nofollow">videos</a><a
                                                                            href="search/dronevideos/index.html"
                                                                            rel="nofollow">dronevideos</a><a
                                                                            href="search/high%2bangle%2bview/index.html"
                                                                            rel="nofollow">high angle view</a><a
                                                                            href="search/top%2bdown%2breveal%2bcity%2baerial/index.html"
                                                                            rel="nofollow">top down reveal city
                                                                            aerial</a><a
                                                                            href="search/african%2bgirl/index.html"
                                                                            rel="nofollow">african girl</a><a
                                                                            href="search/nature/index.html"
                                                                            rel="nofollow">nature</a><a
                                                                            href="search/flying%2bforward%2bover%2bbirds%2bswimming%2bin%2bthe%2bpond/index.html"
                                                                            rel="nofollow">flying forward over birds
                                                                            swimming in the pond</a></li>
                                                                </ul>
                                                            </div>

                                                        </div>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section data-particle_enable="false" data-particle-mobile-disabled="false"
                            class="elementor-section elementor-top-section elementor-element elementor-element-281671ff elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="281671ff" data-element_type="section"
                            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                            <div class="elementor-container elementor-column-gap-custom">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7c725afa"
                                        data-id="7c725afa" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-2fabcc9c elementor-widget elementor-widget-heading"
                                                    data-id="2fabcc9c" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h2 class="elementor-heading-title elementor-size-default">
                                                            Subscribe</h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section data-particle_enable="false" data-particle-mobile-disabled="false"
                            class="elementor-section elementor-top-section elementor-element elementor-element-3d964d6b elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="3d964d6b" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-786ea4c"
                                        data-id="786ea4c" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-3fd995ac elementor-widget elementor-widget-mayosis-pricing-table"
                                                    data-id="3fd995ac" data-element_type="widget"
                                                    data-widget_type="mayosis-pricing-table.default">
                                                    <div class="elementor-widget-container">

                                                        <!-- Element Code start -->

                                                        <div class="dm_pricing_table">
                                                            <div class="pricing_title"
                                                                style="background:rgba(198,201,204,0)">
                                                                <h2 style="color:#1d314f; text-align:center;"> Silver
                                                                </h2>
                                                            </div>
                                                            <div class="pricing_content">
                                                                <div class="pricing_table_title_box">
                                                                    <h3 class="price_tag_table table_pricing_amount">
                                                                        <sub class="pricing_currency">$</sub> 99<span
                                                                            class="pricing_timeframe">/mo</span></h3>
                                                                </div>

                                                                <div class="main_price_content"
                                                                    style="text-align:left;">
                                                                    <ul>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Download <b>5
                                                                                Videos</b> Per Month</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i> <b>1080P Full HD
                                                                            </b>Quality</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Access To All
                                                                            Videos</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Unlimited
                                                                            Broadcast Views</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Unlimited Web
                                                                            Views</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Unlimited /
                                                                            Forever Use License – Royalty-Free</li>
                                                                    </ul>
                                                                </div>
                                                                <a href="downloads/silver/index.html"
                                                                    class="btn_blue_pricing btn"
                                                                    style="background:rgba(255,35,65,0);border-color:rgba(29,49,79,0.44);color:#1d314f;">Purchase</a>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-781fe88e"
                                        data-id="781fe88e" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-7b241fa elementor-widget elementor-widget-mayosis-pricing-table"
                                                    data-id="7b241fa" data-element_type="widget"
                                                    data-widget_type="mayosis-pricing-table.default">
                                                    <div class="elementor-widget-container">

                                                        <!-- Element Code start -->

                                                        <div class="dm_pricing_table">
                                                            <div class="pricing_title"
                                                                style="background:rgba(198,201,204,0)">
                                                                <h2 style="color:#1d314f; text-align:center;"> Gold</h2>
                                                            </div>
                                                            <div class="lable_price_data">
                                                                <span class="label_pricing"
                                                                    style="background:#149632;">Popular Choice</span>
                                                            </div>
                                                            <div class="pricing_content">
                                                                <div class="pricing_table_title_box">
                                                                    <h3 class="price_tag_table table_pricing_amount">
                                                                        <sub class="pricing_currency">$</sub> 199<span
                                                                            class="pricing_timeframe">/mo</span></h3>
                                                                </div>

                                                                <div class="main_price_content"
                                                                    style="text-align:left;">
                                                                    <ul>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Download <b>8
                                                                                Videos</b> Per Month</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i><b>2160P
                                                                                4K+1080p</b> Quality</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Access To All
                                                                            Videos</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Unlimited
                                                                            Broadcast Views</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Unlimited Web
                                                                            Views</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Unlimited /
                                                                            Forever Use License – Royalty-Free</li>
                                                                    </ul>
                                                                </div>
                                                                <a href="downloads/gold/index.html"
                                                                    class="btn_blue_pricing btn"
                                                                    style="background:#ff2341;border-color:#ffffff;color:#ffffff;">Purchase</a>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-715756c3"
                                        data-id="715756c3" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-1dc05e47 elementor-widget elementor-widget-mayosis-pricing-table"
                                                    data-id="1dc05e47" data-element_type="widget"
                                                    data-widget_type="mayosis-pricing-table.default">
                                                    <div class="elementor-widget-container">

                                                        <!-- Element Code start -->

                                                        <div class="dm_pricing_table">
                                                            <div class="pricing_title"
                                                                style="background:rgba(198,201,204,0)">
                                                                <h2 style="color:#1d314f; text-align:center;"> Diamond
                                                                </h2>
                                                            </div>
                                                            <div class="pricing_content">
                                                                <div class="pricing_table_title_box">
                                                                    <h3 class="price_tag_table table_pricing_amount">
                                                                        <sub class="pricing_currency">$</sub> 399<span
                                                                            class="pricing_timeframe">/mo</span></h3>
                                                                </div>

                                                                <div class="main_price_content"
                                                                    style="text-align:left;">
                                                                    <ul>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Download <b>17
                                                                                Videos</b> Per Month</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>2160P 4K+1080p
                                                                            Quality</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Access To All
                                                                            Videos</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i><b>Unlimited</b>
                                                                            Broadcasting</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Unlimited Web
                                                                            Views</li>
                                                                        <li><i class="fa fa-check-circle"
                                                                                aria-hidden="true"></i>Unlimited /
                                                                            Forever Use License – Royalty-Free</li>
                                                                    </ul>
                                                                </div>
                                                                <a href="downloads/diamond/index.html"
                                                                    class="btn_blue_pricing btn"
                                                                    style="background:rgba(255,35,65,0);border-color:rgba(29,49,79,0.44);color:#1d314f;">Purchase</a>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section data-particle_enable="false" data-particle-mobile-disabled="false"
                            class="elementor-section elementor-top-section elementor-element elementor-element-6887b89d elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="6887b89d" data-element_type="section">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-3823d941"
                                        data-id="3823d941" data-element_type="column"
                                        data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-409cc453 elementor-widget elementor-widget-mayosis-icon-box"
                                                    data-id="409cc453" data-element_type="widget"
                                                    data-widget_type="mayosis-icon-box.default">
                                                    <div class="elementor-widget-container">


                                                        <div class="mayosis-icon-box">
                                                            <div class="quality-box">
                                                                <div style="margin-top:-45px"
                                                                    class="add-align-box icon-with-bg">




                                                                    <i aria-hidden="true" class="fas fa-money-bill"></i>
                                                                </div>
                                                                <h4 class="mix-iconb-title">Secure Payment</h4>
                                                                <div class="icon-box-content">
                                                                    <div>We do not share your full credit card, debit
                                                                        card, or bank account number with Third parties.
                                                                        We only receives information that is required to
                                                                        complete and support your transaction. This
                                                                        information may include your name, email
                                                                        address, and Billing address.</div>


                                                                </div>



                                                            </div>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-616655f5"
                                        data-id="616655f5" data-element_type="column"
                                        data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-4c5f1288 elementor-widget elementor-widget-mayosis-icon-box"
                                                    data-id="4c5f1288" data-element_type="widget"
                                                    data-widget_type="mayosis-icon-box.default">
                                                    <div class="elementor-widget-container">


                                                        <div class="mayosis-icon-box">
                                                            <div class="quality-box">
                                                                <div style="margin-top:-45px"
                                                                    class="add-align-box icon-with-bg">




                                                                    <i aria-hidden="true" class="far fa-thumbs-up"></i>
                                                                </div>
                                                                <h4 class="mix-iconb-title">Unlimited Use</h4>
                                                                <div class="icon-box-content">
                                                                    <div>We like to keep things simple too. Our royalty
                                                                        free license is simple and gives you right to
                                                                        use licensed content in perpetuity across
                                                                        different projects.

                                                                    </div>


                                                                </div>



                                                            </div>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-607b4910"
                                        data-id="607b4910" data-element_type="column"
                                        data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-5489bcfd elementor-widget elementor-widget-mayosis-icon-box"
                                                    data-id="5489bcfd" data-element_type="widget"
                                                    data-widget_type="mayosis-icon-box.default">
                                                    <div class="elementor-widget-container">


                                                        <div class="mayosis-icon-box">
                                                            <div class="quality-box">
                                                                <div style="margin-top:-45px"
                                                                    class="add-align-box icon-with-bg">




                                                                    <i aria-hidden="true" class="far fa-angry"></i>
                                                                </div>
                                                                <h4 class="mix-iconb-title">Cancel Anytime</h4>
                                                                <div class="icon-box-content">
                                                                    <div>You are free to cancel your subscription plan
                                                                        at anytime with no additional charges. Once a
                                                                        subscription has been canceled, you still will
                                                                        have access to download content in your account
                                                                        through the end of your paid subscription
                                                                        period.</div>


                                                                </div>



                                                            </div>

                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section data-particle_enable="false" data-particle-mobile-disabled="false"
                            class="elementor-section elementor-top-section elementor-element elementor-element-09c27ef elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                            data-id="09c27ef" data-element_type="section"
                            data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                            <div class="elementor-container elementor-column-gap-default">
                                <div class="elementor-row">

                                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-683cbd4"
                                        data-id="683cbd4" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-f391f25 elementor-widget elementor-widget-mayosis-theme-hero"
                                                    data-id="f391f25" data-element_type="widget"
                                                    data-widget_type="mayosis-theme-hero.default">
                                                    <div class="elementor-widget-container">

                                                        <!-- Element Code start -->

                                                        <div
                                                            class="col-md-12  col-xs-12 col-sm-12 mayosis_theme_hero_box">
                                                            <h2 class="hero-title">Thousands Of Happy Customers!
                                                                <span class="mhero_counter_main">
                                                                </span>
                                                            </h2>
                                                            <div class="hero-description">Here you will find high
                                                                quality resolution Royalty-Free Aerial Videos and many
                                                                more for any project.</div>

                                                        </div>
                                                        <div class="clearfix"></div>

                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-84d5ba3 elementor-widget elementor-widget-eael-testimonial-slider"
                                                    data-id="84d5ba3" data-element_type="widget"
                                                    data-widget_type="eael-testimonial-slider.default">
                                                    <div class="elementor-widget-container">

                                                        <div class="swiper-container-wrap swiper-container-wrap-dots-outside eael-testimonial-slider default-style"
                                                            id="eael-testimonial-84d5ba3">
                                                            <div class="swiper-container eael-testimonial-slider-main swiper-container-84d5ba3"
                                                                data-pagination=".swiper-pagination-84d5ba3"
                                                                data-arrow-next=".swiper-button-next-84d5ba3"
                                                                data-arrow-prev=".swiper-button-prev-84d5ba3"
                                                                data-effect="cube" data-speed="1000" data-loop="1"
                                                                data-grab-cursor="1" data-arrows="1" data-dots="1"
                                                                data-autoplay_speed="3053" data-pause-on-hover="true">

                                                                <div class="swiper-wrapper">










                                                                    <div
                                                                        class="eael-testimonial-item clearfix swiper-slide testimonial-avatar-rounded eael-testimonial-align-center">
                                                                        <div
                                                                            class="eael-testimonial-item-inner clearfix">
                                                                            <div class="eael-testimonial-image">
                                                                                <span
                                                                                    class="eael-testimonial-quote"></span>
                                                                                <figure>
                                                                                    <img src="wp-content/uploads/2021/04/smiling-4654740_640.html"
                                                                                        alt="">
                                                                                </figure>
                                                                            </div>
                                                                            <div class="eael-testimonial-content rating-five"
                                                                                style=" height: px;">
                                                                                <div
                                                                                    class="default-style-testimonial-content">
                                                                                    <div class="eael-testimonial-text">
                                                                                        <p>Great site to find well
                                                                                            produced Drone footage for
                                                                                            your project</p>
                                                                                    </div>
                                                                                    <ul class="testimonial-star-rating">
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <p class="eael-testimonial-user">
                                                                                        Vera Ramalho</p>
                                                                                    <p
                                                                                        class="eael-testimonial-user-company">
                                                                                        Sweet Gurls V.</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>











                                                                    <div
                                                                        class="eael-testimonial-item clearfix swiper-slide testimonial-avatar-rounded eael-testimonial-align-center">
                                                                        <div
                                                                            class="eael-testimonial-item-inner clearfix">
                                                                            <div class="eael-testimonial-image">
                                                                                <span
                                                                                    class="eael-testimonial-quote"></span>
                                                                                <figure>
                                                                                    <img src="wp-content/uploads/2021/04/black-man-4699504_640.html"
                                                                                        alt="">
                                                                                </figure>
                                                                            </div>
                                                                            <div class="eael-testimonial-content rating-five"
                                                                                style=" height: px;">
                                                                                <div
                                                                                    class="default-style-testimonial-content">
                                                                                    <div class="eael-testimonial-text">
                                                                                        <h4
                                                                                            class="review-content__title">
                                                                                            Nice to have options!</h4>
                                                                                        <p class="review-content__text">
                                                                                            Fast, efficient, high
                                                                                            quality clips.</p>
                                                                                    </div>
                                                                                    <ul class="testimonial-star-rating">
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <p class="eael-testimonial-user">
                                                                                        Frances Agyei</p>
                                                                                    <p
                                                                                        class="eael-testimonial-user-company">
                                                                                        Movieshot</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>











                                                                    <div
                                                                        class="eael-testimonial-item clearfix swiper-slide testimonial-avatar-rounded eael-testimonial-align-center">
                                                                        <div
                                                                            class="eael-testimonial-item-inner clearfix">
                                                                            <div class="eael-testimonial-image">
                                                                                <span
                                                                                    class="eael-testimonial-quote"></span>
                                                                                <figure>
                                                                                    <img src="wp-content/uploads/2021/04/beautiful-1337737_640.html"
                                                                                        alt="">
                                                                                </figure>
                                                                            </div>
                                                                            <div class="eael-testimonial-content rating-five"
                                                                                style=" height: px;">
                                                                                <div
                                                                                    class="default-style-testimonial-content">
                                                                                    <div class="eael-testimonial-text">
                                                                                        <p>African Drone Stock has a
                                                                                            wide variety of drone video
                                                                                            clips. I usually find what
                                                                                            I'm looking for. Purchasing
                                                                                            is quick and easy. It's a
                                                                                            pleasure working with
                                                                                            African Drone Stock.</p>
                                                                                    </div>
                                                                                    <ul class="testimonial-star-rating">
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <p class="eael-testimonial-user">
                                                                                        Elisa Alberto</p>
                                                                                    <p
                                                                                        class="eael-testimonial-user-company">
                                                                                        Cine Home</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>











                                                                    <div
                                                                        class="eael-testimonial-item clearfix swiper-slide testimonial-avatar-rounded eael-testimonial-align-center">
                                                                        <div
                                                                            class="eael-testimonial-item-inner clearfix">
                                                                            <div class="eael-testimonial-image">
                                                                                <span
                                                                                    class="eael-testimonial-quote"></span>
                                                                                <figure>
                                                                                    <img src="wp-content/uploads/2021/04/people-875617_1280.html"
                                                                                        alt="">
                                                                                </figure>
                                                                            </div>
                                                                            <div class="eael-testimonial-content rating-five"
                                                                                style=" height: px;">
                                                                                <div
                                                                                    class="default-style-testimonial-content">
                                                                                    <div class="eael-testimonial-text">
                                                                                        <p class="review-content__text">
                                                                                            African Drone Stock has not
                                                                                            only the best prices, they
                                                                                            have the best terms... I
                                                                                            always come here first</p>
                                                                                    </div>
                                                                                    <ul class="testimonial-star-rating">
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <p class="eael-testimonial-user">
                                                                                        Patrick Agyei</p>
                                                                                    <p
                                                                                        class="eael-testimonial-user-company">
                                                                                        Akan Music</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>











                                                                    <div
                                                                        class="eael-testimonial-item clearfix swiper-slide testimonial-avatar-rounded eael-testimonial-align-center">
                                                                        <div
                                                                            class="eael-testimonial-item-inner clearfix">
                                                                            <div class="eael-testimonial-image">
                                                                                <span
                                                                                    class="eael-testimonial-quote"></span>
                                                                                <figure>
                                                                                    <img src="wp-content/uploads/2021/04/man-6036259_640.html"
                                                                                        alt="">
                                                                                </figure>
                                                                            </div>
                                                                            <div class="eael-testimonial-content rating-five"
                                                                                style=" height: px;">
                                                                                <div
                                                                                    class="default-style-testimonial-content">
                                                                                    <div class="eael-testimonial-text">
                                                                                        <p>We use African Drone Stock
                                                                                            regularly for Documentaries,
                                                                                            and music videos. Always a
                                                                                            super-great selection.
                                                                                            Fulfillment is always easy
                                                                                            and quick! So we just keep
                                                                                            on coming back for more!</p>
                                                                                    </div>
                                                                                    <ul class="testimonial-star-rating">
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <p class="eael-testimonial-user">
                                                                                        Joseph B.</p>
                                                                                    <p
                                                                                        class="eael-testimonial-user-company">
                                                                                        Links Video Production</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>











                                                                    <div
                                                                        class="eael-testimonial-item clearfix swiper-slide testimonial-avatar-rounded eael-testimonial-align-center">
                                                                        <div
                                                                            class="eael-testimonial-item-inner clearfix">
                                                                            <div class="eael-testimonial-image">
                                                                                <span
                                                                                    class="eael-testimonial-quote"></span>
                                                                                <figure>
                                                                                    <img src="wp-content/uploads/2021/04/man-920083_640.html"
                                                                                        alt="">
                                                                                </figure>
                                                                            </div>
                                                                            <div class="eael-testimonial-content rating-five"
                                                                                style=" height: px;">
                                                                                <div
                                                                                    class="default-style-testimonial-content">
                                                                                    <div class="eael-testimonial-text">
                                                                                        <section
                                                                                            class="review__content">
                                                                                            <div class="review-content">
                                                                                                <div
                                                                                                    class="review-content__body">
                                                                                                    <p
                                                                                                        class="review-content__text">
                                                                                                        I have used
                                                                                                        African Drone
                                                                                                        Stock for some
                                                                                                        time for my
                                                                                                        small YouTube
                                                                                                        projects. They
                                                                                                        are easy to use
                                                                                                        on a fee basis
                                                                                                        and the
                                                                                                        downloads are
                                                                                                        easy to
                                                                                                        accomplish and
                                                                                                        understand. The
                                                                                                        variety on
                                                                                                        African Drone
                                                                                                        Stock is usually
                                                                                                        good enough that
                                                                                                        I always find
                                                                                                        footage for my
                                                                                                        purposes.</p>
                                                                                                </div>
                                                                                            </div>
                                                                                        </section>
                                                                                        <div class="review__actions">
                                                                                            <div class="review-actions">
                                                                                                <div
                                                                                                    class="review-actions__main">
                                                                                                    <div
                                                                                                        class="review-action brand-find-useful">
                                                                                                        <div
                                                                                                            class="v-popover">
                                                                                                            <div>
                                                                                                                <div> 
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div
                                                                                                        class="brand-share-button-wrapper">
                                                                                                        <div
                                                                                                            class="v-popover">
                                                                                                            <div> </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <ul class="testimonial-star-rating">
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <p class="eael-testimonial-user">
                                                                                        Terry Cooper</p>
                                                                                    <p
                                                                                        class="eael-testimonial-user-company">
                                                                                        Terry Channel</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>











                                                                    <div
                                                                        class="eael-testimonial-item clearfix swiper-slide testimonial-avatar-rounded eael-testimonial-align-center">
                                                                        <div
                                                                            class="eael-testimonial-item-inner clearfix">
                                                                            <div class="eael-testimonial-image">
                                                                                <span
                                                                                    class="eael-testimonial-quote"></span>
                                                                                <figure>
                                                                                    <img src="wp-content/uploads/2021/04/people-913778_640.html"
                                                                                        alt="">
                                                                                </figure>
                                                                            </div>
                                                                            <div class="eael-testimonial-content rating-five"
                                                                                style=" height: px;">
                                                                                <div
                                                                                    class="default-style-testimonial-content">
                                                                                    <div class="eael-testimonial-text">
                                                                                        <h2
                                                                                            class="review-content__title">
                                                                                            Very good content</h2>
                                                                                        <p class="review-content__text">
                                                                                            Very good content. Great
                                                                                            quality and very useful for
                                                                                            my project.</p>
                                                                                    </div>
                                                                                    <ul class="testimonial-star-rating">
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <p class="eael-testimonial-user">
                                                                                        Sakora</p>
                                                                                    <p
                                                                                        class="eael-testimonial-user-company">
                                                                                        Production Studio</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>











                                                                    <div
                                                                        class="eael-testimonial-item clearfix swiper-slide testimonial-avatar-rounded eael-testimonial-align-center">
                                                                        <div
                                                                            class="eael-testimonial-item-inner clearfix">
                                                                            <div class="eael-testimonial-image">
                                                                                <span
                                                                                    class="eael-testimonial-quote"></span>
                                                                                <figure>
                                                                                    <img src="wp-content/uploads/2021/04/woman-837156_640.html"
                                                                                        alt="">
                                                                                </figure>
                                                                            </div>
                                                                            <div class="eael-testimonial-content rating-four"
                                                                                style=" height: px;">
                                                                                <div
                                                                                    class="default-style-testimonial-content">
                                                                                    <div class="eael-testimonial-text">
                                                                                        <section
                                                                                            class="review__content">
                                                                                            <div class="review-content">
                                                                                                <div
                                                                                                    class="review-content__body">
                                                                                                    <p
                                                                                                        class="review-content__text">
                                                                                                        Easy, quick and
                                                                                                        uncomplicated
                                                                                                        purchase.
                                                                                                        Everything
                                                                                                        worked fine just
                                                                                                        how it should.
                                                                                                        They have a huge
                                                                                                        collection of
                                                                                                        all types  of
                                                                                                        aerial clips. I
                                                                                                        will definitely
                                                                                                        purchase again
                                                                                                        on African drone
                                                                                                        stock.</p>
                                                                                                </div>
                                                                                            </div>
                                                                                        </section>
                                                                                    </div>
                                                                                    <ul class="testimonial-star-rating">
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <p class="eael-testimonial-user">
                                                                                        Francisca B</p>
                                                                                    <p
                                                                                        class="eael-testimonial-user-company">
                                                                                        Divina Media</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>











                                                                    <div
                                                                        class="eael-testimonial-item clearfix swiper-slide testimonial-avatar-rounded eael-testimonial-align-center">
                                                                        <div
                                                                            class="eael-testimonial-item-inner clearfix">
                                                                            <div class="eael-testimonial-image">
                                                                                <span
                                                                                    class="eael-testimonial-quote"></span>
                                                                                <figure>
                                                                                    <img src="wp-content/uploads/2021/04/man-3122063_640.html"
                                                                                        alt="">
                                                                                </figure>
                                                                            </div>
                                                                            <div class="eael-testimonial-content rating-four"
                                                                                style=" height: px;">
                                                                                <div
                                                                                    class="default-style-testimonial-content">
                                                                                    <div class="eael-testimonial-text">
                                                                                        <h2
                                                                                            class="review-content__title">
                                                                                            Great service and selections
                                                                                        </h2>
                                                                                        <p class="review-content__text">
                                                                                            Great service and
                                                                                            selections! I had an issue
                                                                                            with one video download, BUT
                                                                                            African Drone Stock provided
                                                                                            great and fast support on
                                                                                            clearing it up.</p>
                                                                                    </div>
                                                                                    <ul class="testimonial-star-rating">
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <p class="eael-testimonial-user">
                                                                                        Walter Jacobson</p>
                                                                                    <p
                                                                                        class="eael-testimonial-user-company">
                                                                                        Empire Videos</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>











                                                                    <div
                                                                        class="eael-testimonial-item clearfix swiper-slide testimonial-avatar-rounded eael-testimonial-align-center">
                                                                        <div
                                                                            class="eael-testimonial-item-inner clearfix">
                                                                            <div class="eael-testimonial-image">
                                                                                <span
                                                                                    class="eael-testimonial-quote"></span>
                                                                                <figure>
                                                                                    <img src="wp-content/uploads/2021/04/woman-1149911_640.html"
                                                                                        alt="">
                                                                                </figure>
                                                                            </div>
                                                                            <div class="eael-testimonial-content rating-five"
                                                                                style=" height: px;">
                                                                                <div
                                                                                    class="default-style-testimonial-content">
                                                                                    <div class="eael-testimonial-text">
                                                                                        <h2
                                                                                            class="review-content__title">
                                                                                            I always find that shots I'm
                                                                                            looking…</h2>
                                                                                        <p class="review-content__text">
                                                                                            I always find that shots I'm
                                                                                            looking for. And everytime
                                                                                            it's so cheap and fast. So I
                                                                                            am more efficient in my
                                                                                            work.</p>
                                                                                    </div>
                                                                                    <ul class="testimonial-star-rating">
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                        <li><i class="fa fa-star"
                                                                                                aria-hidden="true"></i>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <p class="eael-testimonial-user">
                                                                                        Leticia Cereti</p>
                                                                                    <p
                                                                                        class="eael-testimonial-user-company">
                                                                                        Mudae Production</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                                <!-- Add Pagination -->
                                                                <div
                                                                    class="swiper-pagination swiper-pagination-84d5ba3">
                                                                </div>
                                                                <!-- Add Arrows -->
                                                                <div
                                                                    class="swiper-button-next swiper-button-next-84d5ba3">
                                                                    <i class="fa fa-caret-right"></i>
                                                                </div>
                                                                <div
                                                                    class="swiper-button-prev swiper-button-prev-84d5ba3">
                                                                    <i class="fa fa-caret-left"></i>
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="swiper-container eael-testimonial-gallary-pagination  eael_gallery_pagination_hide_on_desktop eael_gallery_pagination_hide_on_mobile eael_gallery_pagination_hide_on_tablet">
                                                                <div class="swiper-wrapper">
                                                                    <div class="swiper-slide">
                                                                        <div class="swiper-slide-container">
                                                                            <div class="eael-pagination-thumb">
                                                                                <img class="eael-thumbnail"
                                                                                    src="wp-content/uploads/2021/04/smiling-4654740_640.html"
                                                                                    alt="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <div class="swiper-slide-container">
                                                                            <div class="eael-pagination-thumb">
                                                                                <img class="eael-thumbnail"
                                                                                    src="wp-content/uploads/2021/04/black-man-4699504_640.html"
                                                                                    alt="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <div class="swiper-slide-container">
                                                                            <div class="eael-pagination-thumb">
                                                                                <img class="eael-thumbnail"
                                                                                    src="wp-content/uploads/2021/04/beautiful-1337737_640.html"
                                                                                    alt="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <div class="swiper-slide-container">
                                                                            <div class="eael-pagination-thumb">
                                                                                <img class="eael-thumbnail"
                                                                                    src="wp-content/uploads/2021/04/people-875617_1280.html"
                                                                                    alt="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <div class="swiper-slide-container">
                                                                            <div class="eael-pagination-thumb">
                                                                                <img class="eael-thumbnail"
                                                                                    src="wp-content/uploads/2021/04/man-6036259_640.html"
                                                                                    alt="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <div class="swiper-slide-container">
                                                                            <div class="eael-pagination-thumb">
                                                                                <img class="eael-thumbnail"
                                                                                    src="wp-content/uploads/2021/04/man-920083_640.html"
                                                                                    alt="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <div class="swiper-slide-container">
                                                                            <div class="eael-pagination-thumb">
                                                                                <img class="eael-thumbnail"
                                                                                    src="wp-content/uploads/2021/04/people-913778_640.html"
                                                                                    alt="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <div class="swiper-slide-container">
                                                                            <div class="eael-pagination-thumb">
                                                                                <img class="eael-thumbnail"
                                                                                    src="wp-content/uploads/2021/04/woman-837156_640.html"
                                                                                    alt="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <div class="swiper-slide-container">
                                                                            <div class="eael-pagination-thumb">
                                                                                <img class="eael-thumbnail"
                                                                                    src="wp-content/uploads/2021/04/man-3122063_640.html"
                                                                                    alt="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="swiper-slide">
                                                                        <div class="swiper-slide-container">
                                                                            <div class="eael-pagination-thumb">
                                                                                <img class="eael-thumbnail"
                                                                                    src="wp-content/uploads/2021/04/woman-1149911_640.html"
                                                                                    alt="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="elementor-element elementor-element-452aefb elementor-widget elementor-widget-spacer"
                                                    data-id="452aefb" data-element_type="widget"
                                                    data-widget_type="spacer.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-spacer">
                                                            <div class="elementor-spacer-inner"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>

        </div>



        <div class="clearfix"></div>




        <footer class="main-footer container-fluid">
            <div class="container">
                <div class="footer-row">

                    <!-- Begin Footer Section-->







                    <div class="footer-widget mx-one">
                        <div class="footer-sidebar widget_digital_about">
                            <div class="sidebar-theme">
                                <img src="images/logo.png" width="150px" alt="Footer Logo" class="img-responsive footer-logo" />
                                <p class="footer-text">We are the African drone pilots, a team that aims to bring to you
                                    the most beautiful and impressive quality footages from Africa and all over the
                                    world. AFRICAN DRONE STOCK is aerial stock footage boutique consisting of the best
                                    drone video clips with High-Quality Content From All Over The World. It was set up
                                    by African Drone Pilot Operators and aircraft pilots with large library of videos as
                                    a solution to provide a portal for aerial videos online with easy access for both
                                    contributors and customers. Read More At About Us Page.</p>



                                <div class="clearfix"></div>
                            </div>

                        </div>
                        <div class="widget_text footer-sidebar widget_custom_html">
                            <div class="textwidget custom-html-widget">
                                <div style="height:10px">

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="footer-widget mx-two">
                        <div class="footer-sidebar widget_nav_menu">
                            <h4 class="footer-widget-title">Others</h4>
                            <div class="menu-footer-menu-container">
                                <ul id="menu-footer-menu" class="menu">
                                    <li id="menu-item-5824"
                                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5824">
                                        <a href="about-us/index.html">About Us</a></li>
                                    <li id="menu-item-5965"
                                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5965">
                                        <a href="contact/index.html">Contact Us</a></li>
                                    <li id="menu-item-5825"
                                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5825">
                                        <a href="faqs/index.html">FAQ&#8217;s</a></li>
                                    <li id="menu-item-5826"
                                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5826">
                                        <a href="privacy-policy-2/index.html">Privacy Policy</a></li>
                                    <li id="menu-item-5827"
                                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5827">
                                        <a href="refund-policy/index.html">Refund Policy</a></li>
                                    <li id="menu-item-5828"
                                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5828">
                                        <a href="terms-conditions/index.html">Terms &#038; Conditions</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="footer-widget mx-three">
                        <div class="footer-sidebar widget_nav_menu">
                            <h4 class="footer-widget-title">Account</h4>
                            <div class="menu-account-menu-container">
                                <ul id="menu-account-menu" class="menu">
                                    <li id="menu-item-2166"
                                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2166">
                                        <a title="						" href="dashboard/index.html">Customer Dashboard</a></li>
                                    <li id="menu-item-4891"
                                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4891">
                                        <a href="vendor-dashboard/index.html">Vendor Dashboard</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="footer-widget mx-four">
                    </div>

                    <div class="footer-widget mx-five">
                        <div class="footer-sidebar dm_subscribe_widget">
                            <div class="sidebar-theme">
                                <div class="single-product-widget">
                                    <h4 class="widget-title"><i class="zil zi-envelope" aria-hidden="true"></i>
                                        Subscribe </h4>
                                    <div class="details-table_subscribe">
                                        <div role="form" class="wpcf7" id="wpcf7-f82-o2" lang="en-US" dir="ltr">
                                            <div class="screen-reader-response">
                                                <p role="status" aria-live="polite" aria-atomic="true"></p>
                                                <ul></ul>
                                            </div>
                                            <form action="https://africandronestock.com/#wpcf7-f82-o2" method="post"
                                                class="wpcf7-form init" novalidate="novalidate" data-status="init">
                                                <div style="display: none;">
                                                    <input type="hidden" name="_wpcf7" value="82" />
                                                    <input type="hidden" name="_wpcf7_version" value="5.4.1" />
                                                    <input type="hidden" name="_wpcf7_locale" value="en_US" />
                                                    <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f82-o2" />
                                                    <input type="hidden" name="_wpcf7_container_post" value="0" />
                                                    <input type="hidden" name="_wpcf7_posted_data_hash" value="" />
                                                </div>
                                                <div class="single-news-letter">
                                                    <span class="wpcf7-form-control-wrap email"><input type="email"
                                                            name="email" value="" size="40"
                                                            class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email nl__item"
                                                            aria-required="true" aria-invalid="false"
                                                            placeholder="Your Email Address" /></span><br />
                                                    <button type="submit" class="nl__item--submit"><i
                                                            class="zil zi-arrow-right"></i></button>
                                                </div>
                                                <div class="wpcf7-response-output" aria-hidden="true"></div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="footer-sidebar widget_mayosis_payment_icons">
                            <div class="sidebar-theme">
                                <h4 class="footer-widget-title"></h4>
                                <!--- Start SVG Sprite --->
                                <svg aria-hidden="true"
                                    style="position: absolute; width: 0; height: 0; overflow: hidden;" version="1.1"
                                    xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <defs>
                                        <symbol id="mayosis-Discover" viewBox="0 0 51 32">
                                            <title>Discover</title>
                                            <path fill="#fff" style="fill: var(--color1, #fff)"
                                                d="M0 0h51.2v32h-51.2v-32z"></path>
                                            <path fill="#f48120" style="fill: var(--color2, #f48120)"
                                                d="M51.2 18.744c0 0-13.088 9.16-37.072 13.256h37.072v-13.256z"></path>
                                            <path fill="#000" style="fill: var(--color3, #000)"
                                                d="M9.568 13.216h-1.6v5.528h1.592c0.848 0 1.456-0.2 1.992-0.64 0.64-0.52 1.016-1.312 1.016-2.12-0.008-1.632-1.232-2.768-3-2.768zM10.84 17.368c-0.344 0.304-0.784 0.44-1.488 0.44h-0.296v-3.656h0.296c0.704 0 1.128 0.128 1.488 0.448 0.376 0.336 0.6 0.848 0.6 1.376s-0.224 1.064-0.6 1.392z">
                                            </path>
                                            <path fill="#000" style="fill: var(--color3, #000)"
                                                d="M13.064 13.216h1.088v5.528h-1.088v-5.528z"></path>
                                            <path fill="#000" style="fill: var(--color3, #000)"
                                                d="M16.816 15.336c-0.656-0.24-0.848-0.4-0.848-0.696 0-0.352 0.344-0.616 0.808-0.616 0.328 0 0.592 0.136 0.88 0.448l0.568-0.736c-0.464-0.408-1.024-0.616-1.64-0.616-0.984 0-1.744 0.68-1.744 1.584 0 0.76 0.352 1.152 1.376 1.52 0.424 0.152 0.64 0.248 0.752 0.312 0.216 0.144 0.328 0.336 0.328 0.576 0 0.448-0.36 0.784-0.848 0.784-0.52 0-0.936-0.256-1.184-0.736l-0.704 0.672c0.504 0.728 1.104 1.056 1.928 1.056 1.128 0 1.928-0.744 1.928-1.816 0-0.888-0.368-1.288-1.6-1.736z">
                                            </path>
                                            <path fill="#000" style="fill: var(--color3, #000)"
                                                d="M18.76 15.984c0 1.624 1.288 2.888 2.944 2.888 0.472 0 0.872-0.088 1.368-0.32v-1.272c-0.432 0.432-0.824 0.608-1.312 0.608-1.096 0-1.872-0.784-1.872-1.904 0-1.064 0.8-1.896 1.824-1.896 0.52 0 0.912 0.184 1.368 0.624v-1.272c-0.48-0.24-0.872-0.336-1.336-0.336-1.664-0.016-2.984 1.272-2.984 2.88z">
                                            </path>
                                            <path fill="#000" style="fill: var(--color3, #000)"
                                                d="M31.704 16.928l-1.488-3.712h-1.192l2.368 5.672h0.584l2.408-5.672h-1.176z">
                                            </path>
                                            <path fill="#000" style="fill: var(--color3, #000)"
                                                d="M34.88 18.744h3.088v-0.936h-2v-1.488h1.92v-0.944h-1.92v-1.224h2v-0.936h-3.088z">
                                            </path>
                                            <path fill="#000" style="fill: var(--color3, #000)"
                                                d="M42.272 14.848c0-1.032-0.72-1.632-1.976-1.632h-1.616v5.528h1.088v-2.224h0.144l1.504 2.224h1.336l-1.76-2.328c0.832-0.168 1.28-0.72 1.28-1.568zM40.088 15.76h-0.32v-1.672h0.336c0.68 0 1.048 0.28 1.048 0.816 0 0.56-0.368 0.856-1.064 0.856z">
                                            </path>
                                            <path fill="#f48120" style="fill: var(--color2, #f48120)" opacity="0.65"
                                                d="M29.36 16c0 1.624-1.328 2.944-2.968 2.944s-2.968-1.32-2.968-2.944 1.328-2.944 2.968-2.944c1.64 0 2.968 1.32 2.968 2.944z">
                                            </path>
                                            <path fill="#f48120" style="fill: var(--color2, #f48120)"
                                                d="M29.36 16c0 1.624-1.328 2.944-2.968 2.944s-2.968-1.32-2.968-2.944 1.328-2.944 2.968-2.944c1.64 0 2.968 1.32 2.968 2.944z">
                                            </path>
                                            <path fill="#000" style="fill: var(--color3, #000)"
                                                d="M42.968 13.424c0-0.096-0.064-0.152-0.184-0.152h-0.16v0.488h0.12v-0.192l0.136 0.192h0.144l-0.16-0.2c0.064-0.016 0.104-0.072 0.104-0.136zM42.76 13.488h-0.016v-0.128h0.024c0.056 0 0.088 0.024 0.088 0.064s-0.032 0.064-0.096 0.064z">
                                            </path>
                                            <path fill="#000" style="fill: var(--color3, #000)"
                                                d="M42.808 13.088c-0.24 0-0.424 0.192-0.424 0.424s0.192 0.424 0.424 0.424c0.232 0 0.424-0.192 0.424-0.424s-0.192-0.424-0.424-0.424zM42.808 13.864c-0.184 0-0.344-0.152-0.344-0.344s0.152-0.352 0.344-0.352c0.184 0 0.336 0.16 0.336 0.352 0 0.184-0.152 0.344-0.336 0.344z">
                                            </path>
                                        </symbol>
                                        <symbol id="mayosis-Mastercard" viewBox="0 0 51 32">
                                            <title>Mastercard</title>
                                            <path fill="#fff" style="fill: var(--color1, #fff)"
                                                d="M0 0h51.2v32h-51.2v-32z"></path>
                                            <path fill="#ea001b" style="fill: var(--color4, #ea001b)"
                                                d="M28.504 16c0 4.197-3.431 7.6-7.664 7.6s-7.664-3.403-7.664-7.6c0-4.197 3.431-7.6 7.664-7.6s7.664 3.403 7.664 7.6z">
                                            </path>
                                            <path fill="#f79e1b" style="fill: var(--color5, #f79e1b)"
                                                d="M38.024 16c0 4.197-3.431 7.6-7.664 7.6s-7.664-3.403-7.664-7.6c0-4.197 3.431-7.6 7.664-7.6s7.664 3.403 7.664 7.6z">
                                            </path>
                                            <path fill="#ff5f01" style="fill: var(--color6, #ff5f01)"
                                                d="M28.504 16c0 3.287-1.3 5.952-2.904 5.952s-2.904-2.665-2.904-5.952c0-3.287 1.3-5.952 2.904-5.952s2.904 2.665 2.904 5.952z">
                                            </path>
                                        </symbol>
                                        <symbol id="mayosis-Paypal" viewBox="0 0 51 32">
                                            <title>Paypal</title>
                                            <path fill="#fff" style="fill: var(--color1, #fff)"
                                                d="M0 0h51.2v32h-51.2v-32z"></path>
                                            <path fill="#1d3586" style="fill: var(--color7, #1d3586)"
                                                d="M31.032 13.36c-0.256-0.304-0.72-0.464-1.328-0.464h-1.824c-0.128 0-0.232 0.088-0.248 0.216l-0.736 4.64c-0.016 0.088 0.056 0.176 0.152 0.176h0.936c0.088 0 0.16-0.064 0.176-0.152l0.208-1.312c0.016-0.12 0.128-0.216 0.248-0.216h0.576c1.2 0 1.896-0.576 2.080-1.72 0.072-0.496-0.008-0.888-0.24-1.168zM29.912 14.592c-0.096 0.648-0.6 0.648-1.080 0.648h-0.272l0.192-1.216c0.008-0.072 0.072-0.128 0.152-0.128h0.128c0.328 0 0.64 0 0.8 0.184 0.088 0.12 0.112 0.288 0.080 0.512z">
                                            </path>
                                            <path fill="#1d3586" style="fill: var(--color7, #1d3586)"
                                                d="M18.016 13.36c-0.256-0.304-0.72-0.464-1.328-0.464h-1.824c-0.128 0-0.232 0.088-0.248 0.216l-0.736 4.64c-0.016 0.088 0.056 0.176 0.152 0.176h0.872c0.128 0 0.232-0.088 0.248-0.208l0.2-1.248c0.016-0.12 0.128-0.216 0.248-0.216h0.576c1.2 0 1.896-0.576 2.080-1.72 0.072-0.504-0.008-0.896-0.24-1.176zM16.896 14.592c-0.096 0.648-0.6 0.648-1.080 0.648h-0.272l0.192-1.216c0.008-0.072 0.072-0.128 0.152-0.128h0.128c0.328 0 0.64 0 0.8 0.184 0.088 0.12 0.112 0.288 0.080 0.512z">
                                            </path>
                                            <path fill="#1d3586" style="fill: var(--color7, #1d3586)"
                                                d="M22.136 14.576h-0.872c-0.072 0-0.136 0.056-0.152 0.128l-0.040 0.24-0.064-0.088c-0.192-0.272-0.608-0.36-1.032-0.36-0.968 0-1.792 0.728-1.952 1.744-0.080 0.504 0.032 0.992 0.328 1.328 0.264 0.312 0.648 0.44 1.104 0.44 0.776 0 1.208-0.496 1.208-0.496l-0.040 0.24c-0.016 0.088 0.056 0.176 0.152 0.176h0.784c0.128 0 0.232-0.088 0.248-0.216l0.472-2.968c0.024-0.088-0.048-0.168-0.144-0.168zM20.92 16.264c-0.088 0.496-0.48 0.824-0.984 0.824-0.256 0-0.456-0.080-0.584-0.232s-0.176-0.368-0.136-0.608c0.080-0.488 0.48-0.832 0.976-0.832 0.248 0 0.448 0.080 0.584 0.24 0.128 0.144 0.184 0.368 0.144 0.608z">
                                            </path>
                                            <path fill="#1d3586" style="fill: var(--color7, #1d3586)"
                                                d="M35.16 14.576h-0.872c-0.072 0-0.136 0.056-0.152 0.128l-0.040 0.24-0.064-0.088c-0.192-0.272-0.608-0.36-1.032-0.36-0.968 0-1.792 0.728-1.952 1.744-0.080 0.504 0.032 0.992 0.328 1.328 0.264 0.312 0.648 0.44 1.104 0.44 0.776 0 1.208-0.496 1.208-0.496l-0.040 0.24c-0.016 0.088 0.056 0.176 0.152 0.176h0.784c0.128 0 0.232-0.088 0.248-0.216l0.472-2.968c0.016-0.088-0.056-0.168-0.144-0.168zM33.936 16.264c-0.088 0.496-0.48 0.824-0.984 0.824-0.256 0-0.456-0.080-0.584-0.232s-0.176-0.368-0.136-0.608c0.080-0.488 0.48-0.832 0.976-0.832 0.248 0 0.448 0.080 0.584 0.24 0.128 0.144 0.184 0.368 0.144 0.608z">
                                            </path>
                                            <path fill="#1d3586" style="fill: var(--color7, #1d3586)"
                                                d="M26.792 14.576h-0.88c-0.080 0-0.16 0.040-0.208 0.112l-1.208 1.768-0.512-1.696c-0.032-0.104-0.128-0.176-0.24-0.176h-0.864c-0.104 0-0.176 0.104-0.144 0.2l0.968 2.816-0.912 1.272c-0.072 0.096 0 0.24 0.128 0.24h0.88c0.080 0 0.16-0.040 0.208-0.112l2.92-4.176c0.064-0.112-0.008-0.248-0.136-0.248z">
                                            </path>
                                            <path fill="#1d3586" style="fill: var(--color7, #1d3586)"
                                                d="M37.176 12.904h-0.84c-0.072 0-0.136 0.056-0.152 0.128l-0.752 4.72c-0.016 0.088 0.056 0.176 0.152 0.176h0.752c0.128 0 0.232-0.088 0.248-0.216l0.736-4.64c0.024-0.088-0.048-0.168-0.144-0.168z">
                                            </path>
                                        </symbol>
                                        <symbol id="mayosis-Stripe" viewBox="0 0 51 32">
                                            <title>Stripe</title>
                                            <path fill="#fff" style="fill: var(--color1, #fff)"
                                                d="M0 0h51.2v32h-51.2v-32z"></path>
                                            <path fill="#6772e5" style="fill: var(--color8, #6772e5)"
                                                d="M42.12 16.224c0-2.344-1.136-4.2-3.312-4.2-2.184 0-3.504 1.856-3.504 4.184 0 2.76 1.568 4.16 3.8 4.16 1.096 0 1.92-0.248 2.544-0.592v-1.848c-0.624 0.312-1.344 0.504-2.248 0.504-0.896 0-1.68-0.32-1.784-1.392h4.488c-0.008-0.112 0.016-0.592 0.016-0.816zM37.584 15.36c0-1.032 0.64-1.464 1.208-1.464 0.56 0 1.16 0.432 1.16 1.464h-2.368z">
                                            </path>
                                            <path fill="#6772e5" style="fill: var(--color8, #6772e5)"
                                                d="M31.76 12.024c-0.896 0-1.48 0.424-1.792 0.72l-0.12-0.568h-2.016v10.696l2.288-0.488 0.008-2.592c0.328 0.24 0.816 0.576 1.624 0.576 1.64 0 3.136-1.32 3.136-4.232-0.008-2.664-1.52-4.112-3.128-4.112zM31.208 18.352c-0.536 0-0.856-0.192-1.080-0.432l-0.016-3.408c0.24-0.264 0.568-0.456 1.096-0.456 0.84 0 1.416 0.936 1.416 2.136 0 1.232-0.568 2.16-1.416 2.16z">
                                            </path>
                                            <path fill="#6772e5" style="fill: var(--color8, #6772e5)"
                                                d="M24.664 11.48l2.304-0.488v-1.864l-2.304 0.488z"></path>
                                            <path fill="#6772e5" style="fill: var(--color8, #6772e5)"
                                                d="M24.664 12.176h2.304v8.032h-2.304v-8.032z"></path>
                                            <path fill="#6772e5" style="fill: var(--color8, #6772e5)"
                                                d="M22.2 12.856l-0.144-0.68h-1.984v8.032h2.288v-5.448c0.544-0.712 1.456-0.576 1.744-0.48v-2.104c-0.296-0.104-1.368-0.304-1.904 0.68z">
                                            </path>
                                            <path fill="#6772e5" style="fill: var(--color8, #6772e5)"
                                                d="M17.6 10.184l-2.24 0.472-0.008 7.352c0 1.36 1.024 2.36 2.384 2.36 0.752 0 1.304-0.136 1.608-0.304v-1.864c-0.296 0.12-1.736 0.536-1.736-0.816v-3.264h1.744v-1.952h-1.744l-0.008-1.984z">
                                            </path>
                                            <path fill="#6772e5" style="fill: var(--color8, #6772e5)"
                                                d="M11.4 14.512c0-0.36 0.296-0.496 0.776-0.496 0.696 0 1.584 0.216 2.28 0.592v-2.16c-0.76-0.304-1.52-0.416-2.28-0.416-1.856 0-3.096 0.968-3.096 2.592 0 2.536 3.488 2.128 3.488 3.216 0 0.424-0.368 0.56-0.88 0.56-0.76 0-1.736-0.312-2.512-0.728v2.192c0.856 0.368 1.712 0.52 2.504 0.52 1.904 0 3.216-0.944 3.216-2.592 0.008-2.744-3.496-2.248-3.496-3.28z">
                                            </path>
                                        </symbol>
                                        <symbol id="mayosis-Visa" viewBox="0 0 51 32">
                                            <title>Visa</title>
                                            <path fill="#fff" style="fill: var(--color1, #fff)"
                                                d="M0 0h51.2v32h-51.2v-32z"></path>
                                            <path fill="#000" style="fill: var(--color3, #000)"
                                                d="M25.448 11.264l-2.048 9.504h-2.48l2.048-9.504h2.48zM35.88 17.4l1.304-3.568 0.752 3.568h-2.056zM38.648 20.76h2.296l-2-9.504h-2.112c-0.48 0-0.88 0.272-1.056 0.696l-3.72 8.8h2.608l0.52-1.416h3.184l0.28 1.424zM32.176 17.664c0.008-2.504-3.496-2.648-3.472-3.768 0.008-0.344 0.336-0.704 1.048-0.792 0.352-0.048 1.336-0.080 2.448 0.424l0.432-2.016c-0.6-0.216-1.368-0.416-2.32-0.416-2.456 0-4.176 1.288-4.192 3.136-0.016 1.368 1.232 2.128 2.168 2.584 0.968 0.464 1.288 0.768 1.288 1.184-0.008 0.64-0.768 0.92-1.48 0.928-1.248 0.016-1.968-0.336-2.544-0.6l-0.448 2.080c0.584 0.264 1.648 0.496 2.76 0.504 2.6 0 4.304-1.28 4.312-3.248zM21.904 11.264l-4.016 9.504h-2.624l-1.976-7.584c-0.12-0.464-0.224-0.64-0.592-0.832-0.592-0.32-1.584-0.624-2.448-0.808l0.056-0.272h4.216c0.536 0 1.024 0.352 1.144 0.968l1.048 5.496 2.576-6.464h2.616z">
                                            </path>
                                        </symbol>
                                    </defs>
                                </svg>

                                <!--- End SVG Sprite --->
                                <!--- Payment Icon --->
                                <div class="payment-icons">
                                    <svg class="mayosisicon mayosis-Paypal">
                                        <use xlink:href="#mayosis-Paypal"></use>
                                    </svg>

                                    <svg class="mayosisicon mayosis-Stripe">
                                        <use xlink:href="#mayosis-Stripe"></use>
                                    </svg>

                                    <svg class="mayosisicon mayosis-Visa">
                                        <use xlink:href="#mayosis-Visa"></use>
                                    </svg>

                                    <svg class="mayosisicon mayosis-Mastercard">
                                        <use xlink:href="#mayosis-Mastercard"></use>
                                    </svg>





                                </div>
                            </div>

                        </div>
                    </div>








                </div>
                <div class="additional-footer">
                    <div class="additional-footer-widget">
                    </div>
                    <div class="additional-footer-widget">
                    </div>

                    <div class="additional-footer-widget">
                    </div>
                </div>
            </div>
        </footer>



        <div class="copyright-footer container-fluid">
            <div class="container">

                <div class="row">
                    <div class="copyright-columned">
                        <div class="copyright-text text-left col-md-6 col-xs-12">
                            Copyright 2021 African Drone Stock, All rights reserved! </div>

                        <div class="copyright-col-right col-md-6 col-xs-12">
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End Footer Section-->



    </div>
    </div>
    <a id="back-to-top" href="#" class="back-to-top" role="button"><i class="zil zi-chevron-up"></i></a>
<script>
    // YouTube Player API for header BG video

// Insert the <script> tag targeting the iframe API
const tag = document.createElement('script');
tag.src = "https://www.youtube.com/iframe_api";
const firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

// Get the video ID passed to the data-video attribute
const bgVideoID = document.querySelector('.js-background-video').getAttribute('data-video');

// Set the player options
const playerOptions = {
  // Autoplay + mute has to be activated (value = 1) if you want to autoplay it everywhere 
  // Chrome/Safari/Mobile
  autoplay: 1,
  mute: 1,
  autohide: 1, 
  modestbranding: 1, 
  rel: 0, 
  showinfo: 0, 
  controls: 0, 
  disablekb: 1, 
  enablejsapi: 1, 
  iv_load_policy: 3,
  // For looping video you have to have loop to 1
  // And playlist value equal to your currently playing video
  loop: 1,
  playlist: bgVideoID,
  
}

// Get the video overlay, to mask it when the video is loaded
const videoOverlay = document.querySelector('.js-video-overlay');

// This function creates an <iframe> (and YouTube player)
// after the API code downloads.
let ytPlayer;
function onYouTubeIframeAPIReady() {
  ytPlayer = new YT.Player('yt-player', {
    width: '1280',
    height: '720',
    videoId: bgVideoID,
    playerVars: playerOptions,
    events: {
      'onReady': onPlayerReady,
      'onStateChange': onPlayerStateChange
    }
  });
}

// The API will call this function when the video player is ready.
function onPlayerReady(event) {
  event.target.playVideo();

  // Get the duration of the currently playing video
  const videoDuration = event.target.getDuration();
  
  // When the video is playing, compare the total duration
  // To the current passed time if it's below 2 and above 0,
  // Return to the first frame (0) of the video
  // This is needed to avoid the buffering at the end of the video
  // Which displays a black screen + the YouTube loader
  setInterval(function (){
    const videoCurrentTime = event.target.getCurrentTime();
    const timeDifference = videoDuration - videoCurrentTime;
    
    if (2 > timeDifference > 0) {
      event.target.seekTo(0);
    }
  }, 1000);
}

// When the player is ready and when the video starts playing
// The state changes to PLAYING and we can remove our overlay
// This is needed to mask the preloading
function onPlayerStateChange(event) {
  if (event.data == YT.PlayerState.PLAYING) {
    videoOverlay.classList.add('header__video-overlay--fadeOut');
  }
}
</script>
</body>
<!-- End Main Layout -->


<!-- Mirrored from africandronestock.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 16 May 2021 18:12:28 GMT -->

</html>
<!-- Page generated by LiteSpeed Cache 3.6.4 on 2021-05-16 15:20:29 -->
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/


Served from: africandronestock.com @ 2021-05-16 15:20:29 by W3 Total Cache
-->